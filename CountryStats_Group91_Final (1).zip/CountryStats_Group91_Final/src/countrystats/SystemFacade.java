package countrystats;

import countrystats.controller.*;
import countrystats.projectbase.interfaces.IFacade;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.tool.EventList;

/**
* A Singleton Facade subclass.
* The SystemFacade class initialize the system.
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class SystemFacade extends Facade{
	
    /**
     * Singleton factory method.
     *
     * @return the Singleton instance of SystemFacade
     */
	public static SystemFacade getInstance()
	{
		if(instance == null)
			instance = new SystemFacade();
		
		return (SystemFacade)instance;
	}
	
    /**
     * This method starts the system.
     */
	public void startUp()
	{
		eventTrigger(EventList.START_SYSTEM);
	}
	
    /**
     * All event-command bindings are registered in this method.
     */
	protected void initController()
	{
		super.initController();
		
		//this command starts the system
		addCommand(EventList.START_SYSTEM, new StartSystemCommand());
		
		//this command response when user successfully logged in to the system
		addCommand(EventList.LOGIN_REQUEST, new LoginRequestCommand());
		
		//this command response when user successfully logged in to the system
		addCommand(EventList.LOGIN_RESPONSE, new LoginResponseCommand());
		
		//this command response when user successfully logged in to the system
		addCommand(EventList.VALIDATION_REQUEST, new ValidationRequestCommand());
		
		//this command response when user successfully logged in to the system
		addCommand(EventList.CALCULATE_ANALYSIS_REQUEST, new CalculateAnalysisCommand());
		
		//this command response when user add viewer
		addCommand(EventList.ADD_VIEWER_REQUEST, new AddViewerCommand());
		
		//this command response when user remove viewer
		addCommand(EventList.REMOVE_VIEWER_REQUEST, new RemoveViewerCommand());
	}
	
}
