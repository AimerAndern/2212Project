/**
 * 
 */
package countrystats.tool;

import java.io.File;

import countrystats.model.UserAccountProxy;

/**
 * This subclass consists exclusively of static methods that
 * set parameters of json file information, including 
 * the address and root of the file
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class Common {
	/**
	 * login result success
	 */
	public static final boolean LOGIN_SUCCESS = true;
	
	/**
	 * login result failed
	 */
	public static final boolean LOGIN_FAILED = false;
	
	/**
	 * validation result success
	 */
	public static final boolean VALIDATION_SUCCESS = true;
	
	/**
	 * validation result failed
	 */
	public static final boolean VALIDATION_FAILED = false;

	/**
	 * This method is used to get the address of the json file through its name
	 * @param jsonFileName address of json file
	 * @return filePath the address of the json file
	 */
	public static String getJsonAddress(String jsonFileName)
	{
		String root = System.getProperty("user.dir");
		String filePath = root + File.separator + "src" + File.separator + "countrystats" + File.separator + "jsonfiles" + File.separator + jsonFileName;
		return filePath;
	}
}
