package countrystats.tool;


import java.util.ArrayList;
/**
 * This subclass initiate exclusively static data structures that
 * defines the type of response and request and their parameters
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class EventList {
	/**
	 * The start system command name
	 */
	public static final String START_SYSTEM = "startSystem";
	
	/**
	 * the login request command name
	 */
	public static final String LOGIN_REQUEST = "loginRequest";
	
	/**
	 * the login response command name
	 */
	public static final String LOGIN_RESPONSE = "loginResponse";
	
	/**
	 * the validation request command name
	 */
	public static final String VALIDATION_REQUEST = "validateRequest";
	
	/**
	 * the validation response command name
	 */
	public static final String VALIDATION_RESPONSE = "validateResponse";
	
	/**
	 * the calculate analysis request command name
	 */
	public static final String CALCULATE_ANALYSIS_REQUEST = "calculateAnalysisRequest";
	
	/**
	 * the calculate analysis response command name
	 */
	public static final String CALCULATE_ANALYSIS_RESPONSE = "calculateAnalysisResponse";
	
	/**
	 * the add viewer request command name
	 */
	public static final String ADD_VIEWER_REQUEST = "addViewerRequest";
	
	/**
	 * the add viewer response command name
	 */
	public static final String ADD_VIEWER_RESPONSE = "addViewerResponse";
	
	/**
	 * the remove viewer request command name
	 */
	public static final String REMOVE_VIEWER_REQUEST = "removeViewerRequest";
	
	/**
	 * the remove viewer response command name
	 */
	public static final String REMOVE_VIEWER_RESPONSE = "removeViewerResponse";
	
	/**
	 * The add bar chart command name
	 */
	public static final String ADD_BAR = "addBarChart";
	
	/**
	 * The add report chart command name
	 */
	public static final String ADD_REPORT = "addReport";
	
	/**
	 * the add scatter chart command name
	 */
	public static final String ADD_SCATTER = "addScatter";
	
	/**
	 * the add line chart command name
	 */
	public static final String ADD_LINE = "addLine";
	
	/**
	 * the add pie chart command name
	 */
	public static final String ADD_PIE = "addPie";
	
	/**
	 *  the enum defines all types of validation request
	 */
	public enum VALIDATION_REQUEST_TYPE
	{
		/**
		 *  country validation request
		 */
		COUNTRY,
		
		/**
		 *  analysis type validation request
		 */
		ANALYSIS_TYPE,
		
		/**
		 *  start year validation request
		 */
		START_YEAR,
		
		/**
		 *  end year validation request
		 */
		END_YEAR
	}
	
	
	/**
	 *  the enum defines all types of validation request
	 */
	public enum VALIDATION_RESPONSE_TYPE
	{
		/**
		 *  country validation request
		 */
		COUNTRY,
		/**
		 *  analysis type validation request
		 */
		ANALYSIS_TYPE,
		/**
		 *  start year validation request
		 */
		START_YEAR,
		/**
		 *  end year validation request
		 */
		END_YEAR
	}

	
	/**
	 * This class defines all information required to send validation request
	 * @author  Zheng Yang
	 * @version 1.1(4/5/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class ValidationRequest
	{
		/**
		 * This validation response type 
		 */
		public VALIDATION_REQUEST_TYPE type;
		
		/**
		 * This validation info
		 */
		public String info;
	}
	
	/**
	 * This class defines all information required to send validation request
	 * @author  Zheng Yang
	 * @version 1.1(4/5/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class ValidationResponse
	{
		/**
		 * This validation response type 
		 */
		public VALIDATION_RESPONSE_TYPE type;
		
		/**
		 * This validation result
		 */
		public boolean result;
		
		/**
		 * This class defines all information required to send add viewer request
		 * @author  Zheng Yang
		 * @version 1.1(4/5/2021)
		 * @since   1.0(4/1/2021) 
		 */
		public String errorMsg;
	}
	
	/**
	 * This class defines all information required to send add viewer request
	 * @author  Zheng Yang
	 * @version 1.1(4/5/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class AddViewerResponse
	{
		/**
		 * the add viewer response result
		 */
		public boolean result;
		
		/**
		 * This add viewer error message
		 */
		public String errorMsg;
	}
	
	
	/**
	 * This class defines all information required to send remove viewer response
	 * @author  Zheng Yang
	 * @version 1.1(4/5/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class RemoveViewerResponse
	{
		/**
		 * the remove viewer result
		 */
		public boolean result;
		
		/**
		 * the remove viewer error message
		 */
		public String errorMsg;
	}
	
	
	/**
	 * This class defines all information required to send calculate analysis response
	 * @author  Zheng Yang
	 * @version 1.1(4/5/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class CalculateAnalysisResponse
	{
		/**
		 * This calculate analysis response type 
		 */
		public boolean result;
		
		/**
		 * This calculate analysis response comment
		 */
		public String comment;
		
		/**
		 * This analysis data
		 */
		public ArrayList<Integer> data;
	}
}
