/**
 * 
 */
package countrystats.tool;

/**
* A Singleton Facade subclass.
* The SystemFacade class initialize the system.
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class Analysis {
	/**
	 * the name of the total population analysis
	 */
	public static final String TOTAL_POPULATION = "Total Population";
	
	/**
	 * the name of the co2 emissions analysis
	 */
	public static final String CO2_EMISSION = "CO2 emissions";
	
	/**
	 * the name of the pm2.5 analysis
	 */
	public static final String PM_2_5 = "PM2.5 air pollution";
	
	/**
	 * the name of the forest area analysis
	 */
	public static final String FOREST_AREA = "Forest area";
	
	/**
	 * the name of the energy use analysis
	 */
	public static final String ENERGY_USE = "Energy use";
	
	/**
	 * the name of the gdp per capita analysis
	 */
	public static final String GDP_PER_CAPITA = "GDP per capita";
	
	/**
	 * the name of the hospital beds analysis
	 */
	public static final String HOSPITAL_BEDS = "Hospital beds";
	
	/**
	 * the name of the government expenditure on education analysis
	 */
	public static final String GOV_EXP_ON_EDUCATION = "Government exp on education";
	
	/**
	 * the name of the mortality rate analysis
	 */
	public static final String MORTALITY_RATE_INFANT = "Mortality rate";
	
	/**
	 * the name of the current health expenditure per capita analysis
	 */
	public static final String CURRENT_HEALTH_EXP_PER_CAPITA = "Current health expenditure per capita";
	
	/**
	 * the name of the current health expenditure analysis
	 */
	public static final String CURRENT_HEALTH_EXP = "Current health expenditure";	
	
	/**
	 * the name of the co2 vs energy used vs pm2.5 analysis
	 */
	public static final String CO2_VS_ENERGY_VS_PM = "CO2 emissions vs Energy use vs vs PM2.5 air pollution";
	
	/**
	 * the name of the pm2.5 vs forest area analysis
	 */
	public static final String PM_VS_FOREST_AREA = "PM2.5 air pollution vs Forest area";
	
	/**
	 * the name of the ratio of co2 emissions and gdp per capita analysis
	 */
	public static final String RATIO_CO2_GDP_PER_CAPITA = "Ratio of CO2 emissions and GDP per capita";
	
	/**
	 * the name of the average forest area analysis
	 */
	public static final String AVG_FOREST_AREA = "Average forest area";
	
	/**
	 * the name of the average government expenditure on education analysis
	 */
	public static final String AVG_GOV_EXP_ON_EDUCATION = "Average of Government exp on education";
	
	/**
	 * the name of the ratio of hospital bed and health expenditure analysis
	 */
	public static final String RATIO_HOSPITALBED_HEALTH_EXP = "Ratio of Hospital beds and Current health exp";
	
	/**
	 * the name of the health expenditure per capita vs mortality analysis
	 */
	public static final String HEALTH_EXP_PER_CAPITA_VS_MORTALITY = "Current health exp per capita vs Mortality rate";
	
	/**
	 * the name of the average government expenditure on education vs health expenditure analysis
	 */
	public static final String AVG_GOV_EXP_ON_EDUCATION_VS_HEALTH_EXP = "Ratio of Government exp on education vs Current health exp";
}
