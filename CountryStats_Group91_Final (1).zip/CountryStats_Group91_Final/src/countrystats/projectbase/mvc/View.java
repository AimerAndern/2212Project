package countrystats.projectbase.mvc;

import java.util.HashMap;
import java.util.Map;

import countrystats.projectbase.interfaces.IMediator;
import countrystats.projectbase.interfaces.IView;
import countrystats.projectbase.patterns.facade.Facade;
/**
 * This subclass implements exclusively static methods that
 * initiated in IModel to set, get and remove collections of model.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public class View implements IView{
	/**
	 * This static variable is used to initialize the private mediator
	 */
	private Map<String, IMediator> mMediators;
	
	/**
	 * This static variable is used to initialize the private view
	 */
	private static View mView;
	
	/**
	 * This method is used to construct view object
	 */
	private View() {
		mMediators = new HashMap<String, IMediator>(); 
	}
	
	/**
	 * This method is used to get the singleton View instance
	 * @return mView the view instance
	 */
	public static View GetInstance()
	{
		if(mView == null)
		{
			mView = new View();
		}
		
		return mView;
	}	
	
	/**
	 * This method is used to add mediator object
	 * @param mediator the IMediator object to be added
	 * @return return true if successfully added
	 */
	@Override
	public boolean addMediator(IMediator mediator) {
		if(!mMediators.containsKey(mediator.getName()))
		{
			mediator.init();
			for (String eventName : mediator.eventsInterested()) {
				Facade.getInstance().addEventListener(eventName, mediator);
			}
			mMediators.put(mediator.getName(), mediator);
			return true;
		}
		
		return false;
	}

	
	/**
	 * This method is used to get the mediator by its name 
	 * @param mediatorName the name of the mediator
	 * @return return mediator by its name
	 */
	@Override
	public IMediator getMediator(String mediatorName) {
		if(mMediators.containsKey(mediatorName))
			return mMediators.get(mediatorName);
		
		return null;
	}

	/**
	 * This method is used to remove mediator object by its name
	 * @param mediatorName the name of the mediator
	 * @return return true if successfully removed
	 */
	@Override
	public boolean removeMediator(String mediatorName) {
		if(mMediators.containsKey(mediatorName) && mMediators.get(mediatorName) != null)
		{
			mMediators.remove(mediatorName);
			return true;
		}
		
		return false;
	}

	/**
	 * This method is used to determine if mediator exists
	 * @param mediatorName the name of the mediator 
	 * @return return true if exists
	 */
	@Override
	public boolean containsMediator(String mediatorName) {
		return mMediators.containsKey(mediatorName);
	}

}
