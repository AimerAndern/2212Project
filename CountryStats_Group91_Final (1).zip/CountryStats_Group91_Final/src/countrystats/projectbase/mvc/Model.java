package countrystats.projectbase.mvc;

import java.util.HashMap;
import java.util.Map;

import countrystats.projectbase.interfaces.IModel;
import countrystats.projectbase.interfaces.IProxy;
/**
 * This subclass implements exclusively static methods that
 * initiated in IModel to set, get and remove collections of model.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021) 
 * @since   1.0(4/1/2021) 
 */
public class Model implements IModel{
	/**
	 * This static variable is used to initialize the proxy object
	 */
	private Map<String, IProxy> mProxies;
	/**
	 * This static variable is used to initialize the controller
	 */
	private static Model mModel;
	/**
	 * This method is used to construct model object
	 */
	private Model() {
		mProxies = new HashMap<String, IProxy>();
	}
	
	
	/**
	 * This method is used to get the singleton Model instance
	 * @return mModel the model instance
	 */
	public static Model GetInstance()
	{
		if(mModel == null)
		{
			mModel = new Model();
		}
		
		return mModel;
	}
	
	/**
	 * This method is used to get the proxy by its name 
	 * @param proxyName, the name of the event
	 * @return return proxy by its name
	 */
	@Override
	public IProxy getProxy(String proxyName) {
		if(!mProxies.containsKey(proxyName))
		{
			return null;
		}
		
		return mProxies.get(proxyName);
			
	}

	
	/**
	 * This method is used to remove proxy object by its name
	 * @param proxyName, the name of the proxy
	 * @return return true if successfully removed
	 */
	@Override
	public boolean removeProxy(String proxyName) {
		if(mProxies.containsKey(proxyName) && mProxies.get(proxyName) != null)
		{
			mProxies.remove(proxyName);
			return true;
		}
		
		return false;
	}

	
	/**
	 * This method is used to determine if proxy exists
	 * @param proxyName, the name of the proxy 
	 * @return return true if exists
	 */
	@Override
	public boolean containsProxy(String proxyName) {
		return mProxies.containsKey(proxyName);

	}

	
	/**
	 * This method is used to add IProxy object
	 * @param proxy, the IProxy object to be added
	 * @return return true if successfully added
	 */
	@Override
	public boolean addProxy(IProxy proxy) {
		if(!mProxies.containsKey(proxy))
		{
			proxy.init();
			mProxies.put(proxy.getName(), proxy);
			return true;
		}
		
		return false;
	}

}
