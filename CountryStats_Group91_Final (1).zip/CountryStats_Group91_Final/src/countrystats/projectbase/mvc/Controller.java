package countrystats.projectbase.mvc;

import java.util.HashMap;
import java.util.Map;

import countrystats.projectbase.interfaces.ICommand;
import countrystats.projectbase.interfaces.IController;
import countrystats.projectbase.interfaces.IEvent;
/**
 * This subclass implements exclusively static methods that
 * initiated in IController to set, get and remove collections of command.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class Controller implements IController{
	/**
	 * This variable is used to initialize the privatecommand object
	 */
	private Map<String, ICommand> mCommands;
	
	/**
	 * This static variable is used to initialize the private controller
	 */
	private static Controller mController;
	
	/**
	 * This method is used to initialize the controller
	 */
	public Controller() {
		mCommands = new HashMap<String, ICommand>();
	}
	
	
	/**
	 * This method is used to get the singleton Controller Instance.
	 * @return mController the instance of controller
	 */
	public static Controller GetInstance()
	{
		if(mController == null)
		{
			mController = new Controller();
		}
		
		return mController;
	}
	
	/**
	 * This method is used to add ICommand object to IEvent object by the name of the event
	 * @param eventName the name of the event
	 * @param command the commend to be added 
	 * @return return true if successfully added
	 */
	@Override
	public boolean addCommand(String eventName, ICommand command) {
		if(!mCommands.containsKey(eventName))
		{
			mCommands.put(eventName, command);
			return true;
		}
		
		return false;
	}

	
	
	/**
	 * This method is used to remove ICommand object from IEvent object by the name of the event
	 * @param eventName the name of the event
	 * @return return true if successfully removed
	 */
	@Override
	public boolean removeCommand(String eventName) {
		if(mCommands.containsKey(eventName))
		{
			mCommands.remove(eventName);
			return true;
		}
		
		return false;
	}
	
	/**
	 * This method is used to determine if event looking for exists
	 * @param eventName the name of the event
	 * @return return true if event exists
	 */
	public boolean containsCommand(String eventName)
	{
		return mCommands.containsKey(eventName) && mCommands.get(eventName) != null;
	}

	
	
	/**
	 * This method is used to execute IEvent object 
	 * @param event the IEvent object
	 */
	@Override
	public void executeCommand(IEvent event) {
		if(!mCommands.containsKey(event.getName()) || mCommands.get(event.getName()) == null)
			return;
		
		mCommands.get(event.getName()).execute(event);
	}

}
