package countrystats.projectbase.patterns.eventcenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.interfaces.IEventCenter;
import countrystats.projectbase.interfaces.IMediator;
import countrystats.projectbase.patterns.event.Event;
import countrystats.projectbase.patterns.facade.Facade;
/**
 * This subclass implements exclusively static methods that
 * initiated in IEventCenter to set, get and remove collections of event center.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class EventCenter implements IEventCenter{
	/**
	 * This static variable is used to initialize the private mediator
	 */
	private static EventCenter mEventCenter;
	
	/**
	 * This static variable is used to initialize the private mediator
	 */
	private Map<String, ArrayList<IMediator>> mEvents;
	
	/**
	 * This method is used to construct event center object
	 */
	private EventCenter() {
		mEvents = new HashMap<String, ArrayList<IMediator>>();
	}
	
	/**
	 * This method is used to get the singleton Model instance
	 * @return mEventCenter the event center instance
	 */
	public static EventCenter getInstance()
	{
		if(mEventCenter == null)
		{
			mEventCenter = new EventCenter();
		}
		
		return mEventCenter;
	}
	
	/**
	 * This method is used to trigger the event object
	 * @param eventName, the name of the event object
	 */
	@Override
	public void eventTrigger(String eventName) {
		eventTrigger(eventName, null);
	}
	
	/**
	 * This method is used to trigger the event object with info object about the event
	 * @param eventName, the name of the event object
	 * @param info, the infomation about the event
	 */
	@Override
	public void eventTrigger(String eventName, Object info) {
		Event event = new Event(eventName, info);
		Facade.getInstance().executeCommand(event);
		
		if(mEvents.containsKey(eventName) && mEvents.get(eventName) != null)
		{
			for (IMediator m : mEvents.get(event.getName())) {
				m.HandleEvent(event);
			}
		}
	}

	
	
	/**
	 * This method is used to add the mediator object to the event by its name 
	 * @param eventName, the name of the event object
	 * @param mediator, the mediator to be added to the event 
	 */
	@Override
	public void addEventListener(String eventName, IMediator mediator) {
		if(!mEvents.containsKey(eventName))
			mEvents.put(eventName, new ArrayList<IMediator>());
		
		ArrayList<IMediator> lst = mEvents.get(eventName);
		if(lst.contains(mediator))
			return;
		
		lst.add(mediator);
	}

	
	/**
	 * This method is used to remove the mediator object from the event by its name 
	 * @param eventName, the name of the event object
	 * @param mediator, the mediator to be removed to the event 
	 */
	@Override
	public void RemoveEventListener(String eventName, IMediator mediator) {
		if(!mEvents.containsKey(eventName))
			return;
		
		ArrayList<IMediator> lst = mEvents.get(eventName);
		if(lst.contains(mediator))
			lst.remove(mediator);
	}
	
}
