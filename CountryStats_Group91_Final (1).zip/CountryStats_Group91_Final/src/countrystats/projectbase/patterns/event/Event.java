package countrystats.projectbase.patterns.event;

import countrystats.projectbase.interfaces.IEvent;
/**
 * This subclass implements exclusively static methods that
 * initiated in IEvent to set, get and remove collections of event objects.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public class Event implements IEvent{
	/**
	 * This variable is used to initialize the private mediator
	 */
	private String mName;
	/**
	 * This variable is used to initialize the private information
	 */
	private Object mBody;
	
	
	/**
	 * This method is used to construct event object
	 * @param name of the event
	 * @param body contains info of the event
	 */
	public Event(String name, Object body)
	{
		mName = name;
		mBody = body;
	}
	
	
	/**
	 * This method is used to get the name of the event object
	 */
	@Override
	public String getName() {
		return mName;
	}

	/**
	 * This method is used to get the information of the event object
	 */
	@Override
	public Object getBody() {
		return mBody;
	}
}
