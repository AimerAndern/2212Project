package countrystats.projectbase.patterns.command;

import countrystats.projectbase.interfaces.ICommand;
import countrystats.projectbase.interfaces.IEvent;
/**
 * This subclass implements exclusively static methods that
 * initiated in IController to set, get and remove collections of command.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class Command implements ICommand{

	
	/**
	 * This method is used to execute the IEvent object
	 * @param event the IEvent object 
	 */
	public void execute(IEvent event) {
	}

}
