package countrystats.projectbase.patterns.facade;

import countrystats.projectbase.interfaces.*;
import countrystats.projectbase.mvc.*;
import countrystats.projectbase.patterns.eventcenter.EventCenter;

public class Facade implements IFacade{
	/**
	 * This protected variable is used to initialize the modem
	 */
	protected Model mModel;
	/**
	 * This protected variable is used to initialize the controller
	 */
	protected Controller mController;
	/**
	 * This protected variable is used to initialize the mView
	 */
	protected View mView;
	/**
	 * This protected variable is used to initialize the protected instance
	 */
	protected static Facade instance;
	
	/**
	 * This method is used to construct facade object
	 */
	protected Facade(){
		instance = this;
		init();
	}
	
	
	/**
	 * This method is used to get the singleton facade instance
	 * @return instance the facade instance
	 */
	public static Facade getInstance()
	{
		if(instance == null)
			instance = new Facade();
		
		return instance;
	}
	
	/**
	 * This method is used to initialize the subclass of facade(model, controller, mediator)
	 */
	protected void init()
	{
		initModel();
		initController();
		initMediator();
	}
	
	
	/**
	 * This method is used to initialize the model
	 */
	protected void initModel()
	{
		mModel = Model.GetInstance();
	}
	
	
	/**
	 * This method is used to initialize controller
	 */
	protected void initController()
	{
		mController = Controller.GetInstance();
	}
	
	/**
	 * This method is used to initialize mediator
	 */
	protected void initMediator()
	{
		mView = View.GetInstance();
	}
	
	/**
	 * This method is used to add IProxy object to model object
	 * @param proxy, the IProxy object to be added
	 * @return return true if successfully added
	 */
	@Override
	public boolean addProxy(IProxy proxy) {
		return mModel.addProxy(proxy);
	}

	@Override
	public IProxy getProxy(String proxyName) {
		return mModel.getProxy(proxyName);
	}

	/**
	 * This method is used to get the proxy by its name 
	 * @param proxyName, the name of the event
	 * @return return proxy by its name
	 */
	@Override
	public boolean removeProxy(String proxyName) {
		return mModel.removeProxy(proxyName);
	}
	/**
	 * This method is used to determine if proxy exists
	 * @param proxyName, the name of the proxy 
	 * @return return true if exists
	 */
	@Override
	public boolean containsProxy(String proxyName) {
		return mModel.containsProxy(proxyName);
	}

	/**
	 * This method is used to add IMediator object
	 * @param mediator, the IMediator object to be added
	 * @return return true if successfully added
	 */
	@Override
	public boolean addMediator(IMediator mediator) {
		return mView.addMediator(mediator);
	}
	/**
	 * This method is used to get the mediator by its name 
	 * @param mediatorName, the name of the mediator
	 * @return return mediator by its name
	 */
	@Override
	public IMediator getMediator(String mediatorName) {
		return mView.getMediator(mediatorName);
	}
	/**
	 * This method is used to remove mediator object by its name
	 * @param mediatorName, the name of the mediator
	 * @return return true if successfully removed
	 */
	@Override
	public boolean removeMediator(String mediatorName) {
		return mView.removeMediator(mediatorName);
	}

	/**
	 * This method is used to determine if mediator exists
	 * @param mediatorName, the name of the mediator 
	 * @return return true if exists
	 */
	@Override
	public boolean containsMediator(String mediatorName) {
		return mView.containsMediator(mediatorName);
	}

	
	/**
	 * This method is used to add command object
	 * @param eventName, the name of the IEvent object
	 * @param command, the ICommand object to be added
	 * @return return true if successfully added
	 */
	@Override
	public boolean addCommand(String eventName, ICommand command) {
		return mController.addCommand(eventName, command);
	}

	/**
	 * This method is used to remove command object from event by its name
	 * @param eventName, the name of the IEvent object
	 * @return return true if successfully removed
	 */
	@Override
	public boolean removeCommand(String eventName) {
		return mController.removeCommand(eventName);
	}
	
	/**
	 * This method is used to determine if command of the event by its name exists
	 * @param eventName, the name of the event
	 * @return return true if exists
	 */
	public boolean containsCommand(String eventName)
	{
		return mController.containsCommand(eventName);
	}
	
	/**
	 * This method is used to execute the command of the event by its name
	 */
	@Override
	public void executeCommand(IEvent event) {
		mController.executeCommand(event);
	}
	
	/**
	 * This method is used to trigger the event by its name
	 * @param eventName, the name of the event
	 */
	@Override
	public void eventTrigger(String eventName) {
		EventCenter.getInstance().eventTrigger(eventName);
	}
	
	/**
	 * This method is used to trigger the event by its name
	 * @param eventName, the name of the event
	 * @param info, the information of the event by its name
	 */
	@Override
	public void eventTrigger(String eventName, Object info) {
		EventCenter.getInstance().eventTrigger(eventName, info);
	}
	/**
	 * This method is used to add mediator object
	 */
	@Override
	public void addEventListener(String eventName, IMediator mediator) {
		EventCenter.getInstance().addEventListener(eventName, mediator);
		
	}

	/**
	 * This method is used to remove mediator of the IEvent object by its name
	 * @param eventName, the name of the IEvent object
	 * @param mediator, the mediator object to be removed
	 */
	@Override
	public void removeEventListener(String eventName, IMediator mediator) {
		EventCenter.getInstance().RemoveEventListener(eventName, mediator);
	}

}
