package countrystats.projectbase.patterns.mediator;

import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.interfaces.IMediator;
/**
 * This subclass initiate exclusively static methods that
 * set, get and remove collections of mediator.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class Mediator implements IMediator{
	/**
	 * This static variable is used to initialize mediator with name "Mediator"
	 */
	public static final String NAME = "Mediator";
	
	/**
	 * This string variable is used to initialize the protected name of mediator
	 */
	protected String mName;
	/**
	 * This string variable is used to initialize the protected view
	 */
	protected Object mView;
	/**
	 * This method is used to construct event listener object
	 * @param name of the mediator
	 */
	public Mediator(String name) {
		mName = name;
	}
	/**
	 * This method is used to initialize the singleton mediator instance
	 */
	@Override
	public void init() {
	}
	
	/**
	 * This method is used to get the name of the mediator object
	 */
	@Override
	public String getName() {
		return mName;
	}

	/**
	 * This method is used to get the list of the events of interst
	 * @return events of interest
	 */
	@Override
	public String[] eventsInterested() {
		return new String[] {};
	}
	
	/**
	 * This method is used to handle the event object
	 */
	@Override
	public void HandleEvent(IEvent event) {
	}
	
}
