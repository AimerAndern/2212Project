package countrystats.projectbase.patterns.proxy;

import countrystats.projectbase.interfaces.IProxy;
/**
 * This subclass implements exclusively static methods that
 * initiated in IProxyto set, get and remove parameters of proxy objects.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class Proxy implements IProxy {
	/**
	 * This string variable is used to initialize the protected name of proxy with "Proxy"
	 */
	public static final String NAME = "Proxy";
	/**
	 * This string variable is used to initialize the protected name of proxy
	 */
	protected String mName;
	/**
	 * This string variable is used to initialize the protected object of content of this class
	 */
	protected Object mData;
	
	/**
	 * This method is used to construct proxy object
	 */
	public Proxy(String name) {
		mName = name;
	}
	
	/**
	 * This method is used to initialize the singleton proxy instance
	 */
	@Override
	public void init()
	{
	}
	
	/**
	 * This method is used to get the information from the proxy object
	 */
	@Override
	public Object getData() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * This method is used to get the name of the proxy object
	 * @return mName the proxy name
	 */
	@Override
	public String getName()
	{
		return mName;
	}
}
