package countrystats.projectbase.interfaces;
/**
 * This interface initiate exclusively static methods that
 * set, get and remove collections of IView.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public interface IView {
	
	/**
	 * This method is declared for use of adding mediator
	 * @param mediator the object of IMediator to be registered
	 */
	public boolean addMediator(IMediator mediator);
	
	
	/**
	 * This method is declared for use of getting mediator with mediatorName given
	 * @param mediatorName the name of mediator of object of IMediator
	 * @return mediator got based on its name
	 */
	public IMediator getMediator(String mediatorName);
	
	
	/**
	 * This method is declared for use of removing mediator
	 * @param mediatorName the name of object of IMediator
	 @return true if mediatorname is successfully removed
	 */
	public boolean removeMediator(String mediatorName);
	
	
	/**
	 * This method is declared for use of determining if the mediator exists
	 * @param mediatorName the name of the object of IMediator
	 * @return true if mediatorname matches a mediator stored in map 
	 */
	public boolean containsMediator(String mediatorName);
}
