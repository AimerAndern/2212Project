package countrystats.projectbase.interfaces;
/**
 * This interface initiates exclusively static methods that
 * set and remove collections of mediator.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public interface IEventCenter {
	
	/**
	 * This method is declared for use of trigger event
	 * @param eventName the name of event
	 */
	public void eventTrigger(String eventName);
	
	
	/**
	 * This method is declared for use of trigger event
	 * @param eventName the name of event
	 * @param info the info of the event
	 */
	public void eventTrigger(String eventName, Object info);
	
	
	/**
	 * This method is declared for use of adding a mediator
	 * @param eventName the name of event
	 * @param mediator the IMediator object
	 */
	public void addEventListener(String eventName, IMediator mediator);
	
	
	/**
	 * This method is declared for use of removing event listener
	 * @param eventName the name of event
	 * @param mediator the IMediator object
	 */
	public void RemoveEventListener(String eventName, IMediator mediator);
}
