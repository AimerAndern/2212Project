package countrystats.projectbase.interfaces;
/**
 * This subclass initiate exclusively static methods that
 * set, get and remove collections of mediator.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public interface IMediator {
	
	
	/**
	 * This method is declared for use of initiate mediator to listen notification and UI events
	 */
	public void init();
	
	
	/**
	 * This method is declared for use of getting name mediator
	 */
	public String getName();
	
	
	/**
	 * This method is declared for use of getting the string of events interested
	 */
	public String[] eventsInterested();
	
	
	/**
	 * This method is declared for opeartion on IEvent object
	 */
	public void HandleEvent(IEvent event);
}
