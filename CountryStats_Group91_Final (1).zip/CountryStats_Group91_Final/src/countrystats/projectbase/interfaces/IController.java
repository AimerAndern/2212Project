package countrystats.projectbase.interfaces;
/**
 * This interface initiates basic static methods of IController that
 * set collections of commands with.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021) 
 * @since   1.0(4/1/2021) 
 */
public interface IController {
	
	/**
	 * This method is declared for use of adding command to event
	 */
	public boolean addCommand(String eventName, ICommand command);
	
	
	/**
	 * This method is declared for use of removing command
	 * @param eventName the name of event
	 */
	public boolean removeCommand(String eventName);
	
	
	/**
	 * This method is declared for use of determine whether command exists
	 * @param eventName the name of event
	 */
	public boolean containsCommand(String eventName);
	
	
	/**
	 * This method is declared for use of command execution
	 * @param event the IEvent object
	 */
	public void executeCommand(IEvent event);
}
