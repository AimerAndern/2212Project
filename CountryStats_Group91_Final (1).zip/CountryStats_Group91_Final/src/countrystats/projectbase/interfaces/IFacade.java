package countrystats.projectbase.interfaces;
/**
 * This subclass initiate exclusively static methods that
 * set, get and remove collections of proxy, command and mediator.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public interface IFacade {
	
	/**
	 * This method is declared for use of adding proxy
	 * @param proxy the IProxy object to be added
	 */
	public boolean addProxy(IProxy proxy);
	
	
	/**
	 * This method is declared for use of getting proxy
	 * @param proxyName the name of proxy
	 */
	public IProxy getProxy(String proxyName);
	
	
	/**
	 * This method is declared for use of removing proxy
	 * @param proxyName the name of proxy
	 */
	public boolean removeProxy(String proxyName);
	
	
	/**
	 * This method is declared for use of determine if proxy exists
	 * @param proxyName the name of proxy
	 */
	public boolean containsProxy(String proxyName);
	
	
	/**
	 * This method is declared for use of adding an IMediator object
	 * @param mediator the IMediator object
	 */
	public boolean addMediator(IMediator mediator);
	
	
	/**
	 * This method is declared for use of getting an IMediator object
	 * @param mediatorName the name of the IMediator object
	 */
	public IMediator getMediator(String mediatorName);
	
	/**
	 * This method is declared for use of removing an IMediator object
	 * @param mediatorName the name of the IMediator object
	 */
	public boolean removeMediator(String mediatorName);
	
	/**
	 * This method is declared for use of determining if the IMediator object exists
	 * @param mediatorName the name of the IMediator object
	 */
	public boolean containsMediator(String mediatorName);
	
	
	/**
	 * This method is declared for use of adding the command
	 * @param eventName the name of the IEvent object
	 * @param command the ICommand object to be added
	 */
	public boolean addCommand(String eventName, ICommand command);
	
	
	/**
	 * This method is declared for use of removing the command
	 * @param eventName the name of the IEvent object
	 */
	public boolean removeCommand(String eventName);
	
	
	/**
	 * This method is declared for use of determining if the ICommand object exists
	 * @param eventName the name of the IEvent object
	 */
	public boolean containsCommand(String eventName);
	
	
	/**
	 * This method is declared for use of executing the command from the event
	 * @param event the IEvent object contains the command to be executed
	 */
	public void executeCommand(IEvent event);
	
	/**
	 * This method is declared for use of trigger under the name of the event
	 * @param eventName the name of the IEvent object to be triggered
	 */
	public void eventTrigger(String eventName);
	
	
	/**
	 * This method is declared for use of trigger under the name of the event with info
	 * @param eventName the name of the IEvent object to be triggered
	 * @param info the value of the object  
	 */
	public void eventTrigger(String eventName, Object info);
	
	
	/**
	 * This method is declared for use of adding mediator to listen notification and UI events
	 * @param eventName the name of the IEvent object to be added
	 * @param mediator the IMediator object to be added into event
	 */
	public void addEventListener(String eventName, IMediator mediator);
	
	
	/**
	 * This method is declared for use of removing mediator to listen notification and UI events
	 * @param eventName the name of the IEvent object to be added
	 * @param mediator the IMediator object to be removed into event
	 */
	public void removeEventListener(String eventName, IMediator mediator);
}
