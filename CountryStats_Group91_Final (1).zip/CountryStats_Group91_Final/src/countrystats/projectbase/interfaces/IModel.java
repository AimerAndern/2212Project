package countrystats.projectbase.interfaces;
/**
 * This interface initiate exclusively static methods that
 * set, get and remove collections of IModel.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public interface IModel {
	
	/**
	 * This method is declared for use of registering proxy
	 * @param proxy the object of IProxy to be registered
	 */
	public boolean addProxy(IProxy proxy);
	
	/**
	 * This method is declared for use of getting registed proxy by its name
	 * @param proxyName the name of the IProxy object to be added
	 */
	public IProxy getProxy(String proxyName);
	
	/**
	 * This method is declared for use of removing proxy
	 * @param proxyName the name of object of IProxy to be registered
	 * @return true if proxy is successfully removed
	 */
	public boolean removeProxy(String proxyName);
	
	/**
	 * This method is declared for use of determining if the proxy exists 
	 * @param proxyName the name of the IProxy object to be added
	 * @return true if proxy name matches one of the proxy stored in map
	 */
	public boolean containsProxy(String proxyName);
}
