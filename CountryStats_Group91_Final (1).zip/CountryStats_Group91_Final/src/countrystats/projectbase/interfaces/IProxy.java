package countrystats.projectbase.interfaces;
/**
 * This interface initiate exclusively static methods that
 * set, get and remove collections of IProxy.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public interface IProxy {
	
	/**
	 * This method is declared for use of initiating an IProxy object
	 */
	public void init();
	
	
	/**
	 * This method is declared for use of getting the name of the proxy
	 */
	public String getName();
	
	/**
	 * This method is declared for use of getting information of the proxy object
	 */
	public Object getData();
}
