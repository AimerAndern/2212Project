package countrystats.projectbase.interfaces;
/**
 * This subclass initiate basic static methods that
 * set and get collections of IEvent object.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public interface IEvent {
	
	/**
	 * This method is declared for use of getting name of IEvent object
	 */
	public String getName();
	
	
	/**
	 * This method is declared for use of getting body of IEvent object
	 */
	public Object getBody();
}
