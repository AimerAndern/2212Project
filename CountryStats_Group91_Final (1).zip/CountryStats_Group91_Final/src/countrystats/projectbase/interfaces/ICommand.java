package countrystats.projectbase.interfaces;
/**
 * This interface consists methods that initiate the operation with the IEvent object
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public interface ICommand {
	
	
	/**
	 * This method is declared for use of event execution
	 * @param event the IEvent object
	 */
	public void execute(IEvent event);
}
