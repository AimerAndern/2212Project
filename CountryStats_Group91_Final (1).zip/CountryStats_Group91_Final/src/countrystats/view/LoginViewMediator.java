/**
 * 
 */
package countrystats.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import countrystats.model.UserAccountProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.mediator.Mediator;
import countrystats.tool.Common;
import countrystats.tool.EventList;

/**
 * This subclass consists exclusively of static methods that
 * construct object of login view mediator, dealing with user 
 * login request and response intermediately.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class LoginViewMediator extends Mediator
{
	/**
	 * This name of the meadiator
	 */
	public static final String NAME = "LoginViewMediator";
	
	/**
	 * This login view object for current application
	 */
	private LoginView mView;

	/**
	 * This method is used to construct login view event listener object
	 */
	public LoginViewMediator() {
		super(NAME);
	}
	
	
	
	/**
	 * This method is used to get the singleton login view mediator instance
	 */
	@Override
	public void init() {
		System.out.println("LoginViewMediator->init()");
		
		mView = new LoginView();
		mView.ButtonLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String username = mView.FieldUsername.getText();
				String password = mView.FieldPassword.getText();
				if(username.equals("") || password.equals(""))
				{
					JOptionPane.showMessageDialog(mView.FrameLogin, "Please enter both username and password to login!");
					return;
				}
				
				Facade.getInstance().eventTrigger(EventList.LOGIN_REQUEST, new String[] {username, password});
			}
		});
		
		//show login panel
		mView.FrameLogin.setVisible(true);
	}
	
	
	/**
	 * This method is used to get the list events of interest
	 * @return the list of login response
	 */
	@Override
	public String[] eventsInterested() {
		return new String[] 
				{
					EventList.LOGIN_RESPONSE
				};
	}
	
	
	/**
	 * This method is used to deal with event operation of login
	 * @param event, the event object to be handled with
	 */
	@Override
	public void HandleEvent(IEvent event) {
		switch(event.getName()){
			case EventList.LOGIN_RESPONSE:
				boolean loginResult = (boolean)event.getBody();
				System.out.println("receive login response: " + loginResult);
				
				if(loginResult == Common.LOGIN_FAILED)
				{
					JOptionPane.showMessageDialog(mView.FrameLogin, "The username or password is incorrect!");
					return;
				}
				
				mView.FrameLogin.setVisible(false);
				break;
				
		}
	}
}
