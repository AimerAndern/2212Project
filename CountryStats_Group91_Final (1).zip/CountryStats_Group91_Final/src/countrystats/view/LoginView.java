/**
 * 
 */
package countrystats.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * This subclass consists exclusively of static methods that
 * construct object of login view framework, parameters of 
 * analysis are added to object
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/4/2020) 
 */
public class LoginView {
	/**
	* the login frame view component
	*/
	public JFrame FrameLogin;
	
	/**
	* the login panel view component
	*/
	public JPanel PanelLogin;
	
	/**
	* the login button view component
	*/
	public JButton ButtonLogin;
	
	/**
	* the username textfield view component
	*/
	public JTextField FieldUsername;
	
	/**
	* the password textfield view component
	*/
	public JPasswordField FieldPassword;
	
	/**
	* the username label 
	*/
	private JLabel LabelUsername;
	
	/**
	* the password label 
	*/
	private JLabel LabelPassword;

	/**
	 * This method is used to construct the login view object  
	 */
	public LoginView()
	{
		FrameLogin = new JFrame();
		FrameLogin.setTitle("Country Statistics");
		FrameLogin.setBounds(700, 300, 350, 200);
		FrameLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		PanelLogin = new JPanel();
		PanelLogin.setLayout(null);
		FrameLogin.add(PanelLogin);
		
		LabelUsername = new JLabel("Username:");
		LabelUsername.setBounds(20,  40, 80, 20);
		PanelLogin.add(LabelUsername);
		
		LabelPassword = new JLabel("password:");
		LabelPassword.setBounds(20, 60, 80, 20);
		PanelLogin.add(LabelPassword);
		
		FieldUsername = new JTextField(20);
		FieldUsername.setBounds(100, 40, 165, 20);
		PanelLogin.add(FieldUsername);
		
		
		FieldPassword = new JPasswordField(20);
		FieldPassword.setBounds(100, 60, 165, 20);
		PanelLogin.add(FieldPassword);
		
		ButtonLogin = new JButton("Login");
		ButtonLogin.setBounds(100, 90, 80, 30);
		PanelLogin.add(ButtonLogin);
	}
	
}
