/**
 * 
 */
package countrystats.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.mvc.View;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.mediator.Mediator;
import countrystats.tool.Common;
import countrystats.tool.EventList;
import countrystats.tool.EventList.AddViewerResponse;
import countrystats.tool.EventList.RemoveViewerResponse;
import countrystats.tool.EventList.VALIDATION_RESPONSE_TYPE;

/**
 * This subclass consists exclusively of static methods that
 * construct object of main view, dealing with interaction of 
 * response and request with users
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class MainViewMediator extends Mediator{
	/**
	 * This name of the mediator
	 */
	public static final String NAME = "MainViewMediator";
	
	/**
	 * This name of bar chart
	 */
	public static final String BAR = "bar chart";
	
	/**
	 * This name of scatter chart
	 */
	public static final String SCATTER = "scatter chart";
	
	/**
	 * This name of line chart
	 */
	public static final String LINE = "line chart";
	
	/**
	 * This name of pie chart
	 */
	public static final String PIE = "pie chart";
	
	/**
	 * This name of report chart
	 */
	public static final String REPORT = "report";
	
	/**
	 * This main view component
	 */
	private MainView mView;
	
	/**
	 * This method is used to construct main view event listener object
	 */
	public MainViewMediator() {
		super(NAME);
	}
	
	/**
	 * This method is used to get the singleton main view event listener instance
	 */
	public void init()
	{
		System.out.println("MainViewMediator->init()");
		
		mView = new MainView();
		mView.FrameMain.setVisible(true);
		
		mView.ComboBoxViewer.addItem(BAR);
		mView.ComboBoxViewer.addItem(SCATTER);
		mView.ComboBoxViewer.addItem(REPORT);
		mView.ComboBoxViewer.addItem(LINE);
		mView.ComboBoxViewer.addItem(PIE);
		
		//action listener for user select country from drop-down menu
		mView.ComboBoxCountry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String countrySelected = (String)mView.ComboBoxCountry.getSelectedItem();
				sendMenuSelectionRequest(EventList.VALIDATION_REQUEST_TYPE.COUNTRY, countrySelected);
			}
		});
		
		//action listener for user select analysis type from drop-down menu
		mView.ComboBoxAnalysisType.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String analysisTypeSelected = (String)mView.ComboBoxAnalysisType.getSelectedItem();
				sendMenuSelectionRequest(EventList.VALIDATION_REQUEST_TYPE.ANALYSIS_TYPE, analysisTypeSelected);
			}
		});
		
		//action listener for user select start year from drop-down menu
		mView.ComboBoxStartYear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String startYearSelected = (String)mView.ComboBoxStartYear.getSelectedItem();
				sendMenuSelectionRequest(EventList.VALIDATION_REQUEST_TYPE.START_YEAR, startYearSelected);
			}
		});
		
		//action listener for user select end year from drop-down menu
		mView.ComboBoxEndYear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String endYearSelected = (String)mView.ComboBoxEndYear.getSelectedItem();
				sendMenuSelectionRequest(EventList.VALIDATION_REQUEST_TYPE.END_YEAR, endYearSelected);
			}
		});
		
		//action listener for user press add viewer button
		mView.ButtonAddViewer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String viewer = (String)mView.ComboBoxViewer.getSelectedItem();
				Facade.getInstance().eventTrigger(EventList.ADD_VIEWER_REQUEST, viewer);
			}
		});
		
		//action listener for user press add viewer button
		mView.ButtonRemoveViewer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String viewer = (String)mView.ComboBoxViewer.getSelectedItem();
				Facade.getInstance().eventTrigger(EventList.REMOVE_VIEWER_REQUEST, viewer);
			}
		});
		
		//action listener for user press calculate button
		mView.ButtonCalculate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(mView.ComboBoxAnalysisType.getSelectedItem().equals(".") || mView.ComboBoxCountry.getSelectedItem().equals(".") ||
				   mView.ComboBoxStartYear.getSelectedItem().equals(".") || mView.ComboBoxEndYear.getSelectedItem().equals("."))
				{
					JOptionPane.showMessageDialog(mView.FrameMain, "Please select all parameters before calculating analysis");
					return;
				}
				
				mView.PanelWest.removeAll();
				refresh();
				Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_REQUEST);
			}
		});
	}
	
	/**
	 * This method is used to get the list of events of interest
	 * @return the list of events of interest
	 */
	@Override
	public String[] eventsInterested() {
		return new String[] 
				{
					//add interested events here
					EventList.VALIDATION_RESPONSE,
					EventList.ADD_VIEWER_RESPONSE,
					EventList.REMOVE_VIEWER_RESPONSE,
					EventList.ADD_BAR,
					EventList.ADD_REPORT,
					EventList.ADD_SCATTER,
					EventList.ADD_PIE,
					EventList.ADD_LINE,
					EventList.CALCULATE_ANALYSIS_RESPONSE
				};
	}
	
	/**
	 * This method is used to handle potential responses of the validation
	 */
	@Override
	public void HandleEvent(IEvent event) {
		switch(event.getName()){
			//handle all interested events here
			case EventList.VALIDATION_RESPONSE:{
				EventList.ValidationResponse response = (EventList.ValidationResponse)event.getBody();
				//if validation failed
				if(response.result == Common.VALIDATION_FAILED)
				{
					handleValidationError(response.type,response.errorMsg);
				}
				else {
					System.out.println("success");
					handleValidationSuccess(response.type);
				}
				break;
			}	
			
			case EventList.ADD_BAR: {
				JFreeChart barChart = (JFreeChart)event.getBody();
				ChartPanel chartPanel = new ChartPanel(barChart);
				chartPanel.setPreferredSize(new Dimension(400, 300));
				chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
				chartPanel.setBackground(Color.white);
				chartPanel.setAutoscrolls(true);
				mView.PanelWest.add(chartPanel);
				refresh();
				break;
			}
			
			case EventList.ADD_REPORT: {
				JScrollPane outputScrollPane = new JScrollPane((JTextArea)event.getBody());
				outputScrollPane.setAutoscrolls(true);
				mView.PanelWest.add(outputScrollPane);
				refresh();
				break;
			}
			
			case EventList.ADD_PIE: {
				ChartPanel chartPanel = new ChartPanel((JFreeChart)event.getBody());
				chartPanel.setPreferredSize(new Dimension(400, 300));
				chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
				chartPanel.setBackground(Color.white);
				mView.PanelWest.add(chartPanel);
				refresh();
				break;
			}
			
			case EventList.ADD_SCATTER:{
				ChartPanel chartPanel = new ChartPanel((JFreeChart)event.getBody());
				chartPanel.setPreferredSize(new Dimension(400, 300));
				chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
				chartPanel.setBackground(Color.white);
				mView.PanelWest.add(chartPanel);
				refresh();
				break;
			}
			
			case EventList.ADD_LINE:{
				ChartPanel chartPanel = new ChartPanel((JFreeChart)event.getBody());
				chartPanel.setPreferredSize(new Dimension(400, 300));
				chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
				chartPanel.setBackground(Color.white);
				mView.PanelWest.add(chartPanel);
				refresh();
				break;
			}
			
			case EventList.ADD_VIEWER_RESPONSE:{
				AddViewerResponse response = (AddViewerResponse)event.getBody();
				if(response.result == false){
					JOptionPane.showMessageDialog(mView.FrameMain, response.errorMsg);
					mView.ComboBoxViewer.setSelectedItem(".");
				}
				else {
					JOptionPane.showMessageDialog(mView.FrameMain, "the viewer is successfully added!");
				}
				break;
			}
			
			case EventList.REMOVE_VIEWER_RESPONSE:{
				RemoveViewerResponse response = (RemoveViewerResponse)event.getBody();
				if(response.result == false){
					JOptionPane.showMessageDialog(mView.FrameMain, response.errorMsg);
					mView.ComboBoxViewer.setSelectedItem(".");
				}
				else {
					JOptionPane.showMessageDialog(mView.FrameMain, "the viewer is successfully removed!");
				}
				break;
			}
			
			case EventList.CALCULATE_ANALYSIS_RESPONSE:{
				JOptionPane.showMessageDialog(mView.FrameMain, "Current Analysis is not possible. Please reselect!");
			}
				
		}
		
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		if(proxy.getCurrentCountry() == null)
			System.out.println(".");
		else
			System.out.println(proxy.getCurrentCountry());
		
		if(proxy.getCurrentAnalysisType() == null)
			System.out.println(".");
		else
			System.out.println(proxy.getCurrentAnalysisType());
		
		if(proxy.getCurrentStartYear() == null)
			System.out.println(".");
		else
			System.out.println(proxy.getCurrentStartYear());
		
		if(proxy.getCurrentEndYear() == null)
			System.out.println(".");
		else
			System.out.println(proxy.getCurrentEndYear());
	}


	   /**
	   * This is the main method which makes use of addNum method.
	   */
	private void refresh() {
		mView.FrameMain.setVisible(false);
		mView.FrameMain.setVisible(true);
		
	}

	/**
	   * this is the method to handle validation success event
	   * @param type validation response type
	   */
	private void handleValidationSuccess(VALIDATION_RESPONSE_TYPE type) {
		switch(type){
		case COUNTRY:
			if(!mView.ComboBoxStartYear.getSelectedItem().equals("."))
				mView.ComboBoxStartYear.setSelectedItem(".");
			
			if(!mView.ComboBoxEndYear.getSelectedItem().equals("."))
				mView.ComboBoxEndYear.setSelectedItem(".");
			break;
			
		case ANALYSIS_TYPE:
			if(!mView.ComboBoxViewer.getSelectedItem().equals("."))
				mView.ComboBoxViewer.setSelectedItem(".");
			
			if(!mView.ComboBoxCountry.getSelectedItem().equals("."))
				mView.ComboBoxCountry.setSelectedItem(".");
			
			if(!mView.ComboBoxStartYear.getSelectedItem().equals("."))
				mView.ComboBoxStartYear.setSelectedItem(".");
			
			if(!mView.ComboBoxEndYear.getSelectedItem().equals("."))
				mView.ComboBoxEndYear.setSelectedItem(".");
			break;
		}
		
	}

	/**
	   * This method set up the countries
	   * @param countries contains all country name
	   */
	public void setupCountry(Iterator<String> countries){
		while(countries.hasNext())
		{
			mView.ComboBoxCountry.addItem(countries.next());
		}
	}
	
	/**
	   * This method set up the analysis types
	   * @param analysisTypes contains all analysis type name
	   */
	public void setupAnalysisType(Iterator<String> analysisTypes){
		while(analysisTypes.hasNext())
		{
			mView.ComboBoxAnalysisType.addItem(analysisTypes.next());
		}
	}
	
	/**
	   * This method set up the years
	   * @param years contains start and end years
	   */
	public void setupYear(Integer[] years){
		Integer start = years[0], end = years[1];
		
		for(Integer i = start; i <= end; i++)
		{
			mView.ComboBoxStartYear.addItem(i.toString());
			mView.ComboBoxEndYear.addItem(i.toString());
		}
	}
	
	/**
	   * This method send validation request
	   * @param type contains all analysis type name
	   * @param selected validation type
	   */
	private void sendMenuSelectionRequest(EventList.VALIDATION_REQUEST_TYPE type, String selected)
	{
		//set up request
		EventList.ValidationRequest request = new EventList.ValidationRequest();
		request.type = type;
		request.info = selected;
		
		Facade.getInstance().eventTrigger(EventList.VALIDATION_REQUEST, request);
	}
	
	/**
	   * This method handles validation error
	   * @param type is current validation type
	   * @param errormsg contains the error message
	   */
	private void handleValidationError(EventList.VALIDATION_RESPONSE_TYPE type, String errorMsg)
	{
		JOptionPane.showMessageDialog(mView.FrameMain, errorMsg);
		switch(type){
		
			case COUNTRY:
				if(!mView.ComboBoxCountry.getSelectedItem().equals("."))
					mView.ComboBoxCountry.setSelectedItem(".");
				
				if(!mView.ComboBoxStartYear.getSelectedItem().equals("."))
					mView.ComboBoxStartYear.setSelectedItem(".");
				
				if(!mView.ComboBoxEndYear.getSelectedItem().equals("."))
					mView.ComboBoxEndYear.setSelectedItem(".");
				break;
				
			case ANALYSIS_TYPE:
				break;
				
			case START_YEAR:
				if(!mView.ComboBoxStartYear.getSelectedItem().equals("."))
					mView.ComboBoxStartYear.setSelectedItem(".");
				
				if(!mView.ComboBoxEndYear.getSelectedItem().equals("."))
					mView.ComboBoxEndYear.setSelectedItem(".");
				break;
				
			case END_YEAR:
				if(!mView.ComboBoxStartYear.getSelectedItem().equals("."))
					mView.ComboBoxStartYear.setSelectedItem(".");
				
				if(!mView.ComboBoxEndYear.getSelectedItem().equals("."))
					mView.ComboBoxEndYear.setSelectedItem(".");
				break;
		}
	}
}
