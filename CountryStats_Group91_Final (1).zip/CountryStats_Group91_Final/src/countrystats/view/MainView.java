package countrystats.view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneLayout;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYSplineRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
/**
 * This subclass consists exclusively of static methods that
 * construct object of main view, dealing with interaction of 
 * response and request with users
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/4/2020) 
 */
public class MainView{
	/**
	 * the frame component of mainview
	 */
	public JFrame FrameMain;
	
	/**
	 * the main panel component of mainview
	 */
	public JPanel PanelMain;
	
	/**
	 * the chart panel component of mainview
	 */
	public JPanel PanelWest;
	
	/**
	 * the country combobox component of mainview
	 */
	public JComboBox ComboBoxCountry;
    
	/**
	 * the start year combobox component of mainview
	 */
	public JComboBox ComboBoxStartYear;
    
	/**
	 * the end year combobox component of mainview
	 */
	public JComboBox ComboBoxEndYear;
    
	/**
	 * the viewer combobox component of mainview
	 */
	public JComboBox ComboBoxViewer;
    
	/**
	 * the analysis type combobox component of mainview
	 */
	public JComboBox ComboBoxAnalysisType;
    
	/**
	 * the add viewer button component of mainview
	 */
	public JButton ButtonAddViewer;
	
	/**
	 * the remove button component of mainview
	 */
    public JButton ButtonRemoveViewer;
    
	/**
	 * the calculate button component of mainview
	 */
    public JButton ButtonCalculate;

	
	/**
	 * This method is used to construct the main view object  
	 */
	public MainView() {
        //set main panel
        PanelMain = new JPanel();
        PanelMain.setLayout(new BorderLayout());

		// Set top bar
		JLabel labelCountry = new JLabel("Choose a country: ");
		ComboBoxCountry = new JComboBox();
		ComboBoxCountry.addItem(".");

		JLabel labelFrom = new JLabel("From");
		JLabel labelTo = new JLabel("To");
		
		ComboBoxStartYear = new JComboBox();
		ComboBoxStartYear.addItem(".");
		
		ComboBoxEndYear = new JComboBox();
		ComboBoxEndYear.addItem(".");
		
		JPanel panelNorth = new JPanel();
		panelNorth.add(labelFrom);
		panelNorth.add(labelTo);
		panelNorth.add(ComboBoxCountry);
		panelNorth.add(ComboBoxStartYear);
		panelNorth.add(ComboBoxEndYear);

		// Set bottom bar
		ButtonCalculate = new JButton("Recalculate");

		JLabel labelViewer = new JLabel("Available Views: ");
		ComboBoxViewer = new JComboBox();
		ComboBoxViewer.addItem(".");
		ButtonAddViewer = new JButton("+");
		ButtonRemoveViewer = new JButton("-");

		JLabel labelAnalysisType = new JLabel("        Choose analysis method: ");
		ComboBoxAnalysisType = new JComboBox();
		ComboBoxAnalysisType.setFont(new Font("SansSerif", Font.BOLD, 10));
		ComboBoxAnalysisType.addItem(".");

		JPanel panelSouth = new JPanel();
		panelSouth.add(labelViewer);
		panelSouth.add(ComboBoxViewer);
		panelSouth.add(ButtonAddViewer);
		panelSouth.add(ButtonRemoveViewer);
		panelSouth.add(labelAnalysisType);
		panelSouth.add(ComboBoxAnalysisType);
		panelSouth.add(ButtonCalculate);

		JPanel panelEast = new JPanel();

		// Set charts region
		PanelWest = new JPanel();
		PanelWest.setAutoscrolls(true);
		PanelWest.setLayout(new GridLayout(2, 0));

		PanelMain.add(panelNorth, BorderLayout.NORTH);
		PanelMain.add(panelEast, BorderLayout.EAST);
		PanelMain.add(panelSouth, BorderLayout.SOUTH);
		PanelMain.add(PanelWest);
		
		//set frame
        FrameMain = new JFrame();
        FrameMain.setTitle("Country Statistics");
        FrameMain.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        FrameMain.setBounds(700, 200, 1000, 600);
        FrameMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FrameMain.setContentPane(PanelMain);
	}
}
