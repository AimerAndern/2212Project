/**
 * 
 */
package countrystats.model;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import countrystats.projectbase.patterns.event.Event;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.proxy.Proxy;
import countrystats.tool.Common;
import countrystats.tool.EventList;

/**
* User account proxy
* This proxy class is in charge of user account management.
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class UserAccountProxy extends Proxy{
	
	public static final String NAME = "UserAccountProxy";
	
	private UserAccountDefine mData;
	
	/**
	 * This method is used to refer immediate parent class instance variable. 
	 */
	public UserAccountProxy() {
		super(NAME);
	}
	
	
	/**
	 * This method is used to initiate the user account proxy
	 */
	@Override
	public void init()
	{
		System.out.println("UserAccountProxy->init()");
		
	    mData = new UserAccountDefine();
	    mData.userAccount = new HashMap<String, String>();
	    
		setupData();
	}
	
	
	/**
	 * This method is the getter method used to get the data of current User. 
	 * @return mData.currentUser The current user data.
	 */
	public String getCurrentUser()
	{
		return mData.currentUser;
	}
	
	/**
	 * This method is the method used to login with user's password and name.
	 * @param username The string object of user name.
	 * @param password The string object of password 
	 */
	public void tryLogin(String username, String password)
	{
		if(!mData.userAccount.containsKey(username) || !mData.userAccount.get(username).equals(password))
		{
			Facade.getInstance().eventTrigger(EventList.LOGIN_RESPONSE, Common.LOGIN_FAILED);
			return;
		}
			
		mData.currentUser = username;
		Facade.getInstance().eventTrigger(EventList.LOGIN_RESPONSE, Common.LOGIN_SUCCESS);
	}
	
	
	/**
	 * This method is used to set up and stores all relevant information required. 
	 * This function produces an object contains user name and password 
	 */
	private void setupData()
	{
		try 
		{
			FileReader reader = new FileReader(Common.getJsonAddress("UserAccountDefine.txt"));
		    JSONParser jsonParser = new JSONParser();
		    
		    JSONObject object = (JSONObject)jsonParser.parse(reader);
		    
		    for(Iterator iterator = object.keySet().iterator(); iterator.hasNext();) {
		        String key = (String) iterator.next();
		        
		        JSONObject info = (JSONObject)object.get(key);
		        String username = (String)info.get("Username");
		        String password = (String)info.get("Password");
		        
		        mData.userAccount.put(username, password);
		    }
		    
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("UserAccountDefine.txt not found");
		}
		catch (IOException e) 
		{
			System.out.println("Cannot parse UserAccountDefine.txt");
		} 
	    catch (ParseException e) {
			System.out.println("Cannot parse UserAccountDefine.txt");
		}
	}
}
