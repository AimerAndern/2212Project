/**
 * 
 */
package countrystats.model;

import java.util.Map;

/**
* UserAccount VO class, maintains all user accounts created in this system.
* The SystemFacade class initialize the system.
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class UserAccountDefine {
	public Map<String, String> userAccount;
	
	public String currentUser;
}
