/**
 * 
 */
package countrystats.model;

import java.util.ArrayList;
import java.util.Map;

import countrystats.tool.EventList;
import countrystats.tool.EventList.VALIDATION_RESPONSE_TYPE;

/**
 * This subclass consists exclusively of static methods that
 * set collections of analysis setting successfully 
 * validated response received after request operation.
 * <p>The methods of this subclass initialize the 
 * instance of analysis setting to define from other 
 * subclasses of the program.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class AnalysisSettingDefine {
	/**
	 * countryname-info combination
	 */
	public Map<String, CountryInfo> Countries;
	
	/**
	 * analysisName-info combination
	 */
	public Map<String, AnalysisInfo> Analysis;
	
	/**
	 * the name of the current country
	 */
	public String CurrentCountry;
	
	/**
	 * The name of the current analysis type
	 */
	public String CurrentAnalysisType;
	
	/**
	 * The current analysis start year
	 */
	public Integer CurrentStartYear;
	
	/**
	 * The current analysis end year
	 */
	public Integer CurrentEndYear;
	
	/**
	 * All viewers available 
	 */
	public ArrayList<String> currentViewers;
	
	
	/**
	 * This class contains information of an analysis
	 * @author  Zheng Yang, Rui Zhu
	 * @version 1.2(4/7/2021)
	 * @since   1.0(4/1/2021) 
	 */
	public static class AnalysisInfo
	{
		/**
		 * Indicate if the analysis support pie chart
		 */
		public Boolean PieChart;
		
		/**
		 * The world bank code for current analysis type
		 */
		public String Url;
	}
	
    /**
    * This subclass consists public instance of country information 
    * @author  Zheng Yang, Rui Zhu
    * @version 1.1(4/5/2021)
    * @since   1.0(4/1/2021) 
    */
	public static class CountryInfo{
		public Integer Code;
		public String Name;
		public String ISO2DigitAlpha;
		public String ISO3DigitAlpha;
		public Integer StartYear;
		public Integer EndYear;
		public boolean Availability;
	}
}
