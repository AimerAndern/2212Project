/**
 * 
 */
package countrystats.model;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import countrystats.model.AnalysisSettingDefine.AnalysisInfo;
import countrystats.model.AnalysisSettingDefine.CountryInfo;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.proxy.Proxy;
import countrystats.tool.Common;
import countrystats.tool.EventList;
import countrystats.tool.EventList.AddViewerResponse;
import countrystats.tool.EventList.RemoveViewerResponse;
import countrystats.tool.EventList.VALIDATION_RESPONSE_TYPE;

/**
 * This subclass consists exclusively static methods that
 * set collections of proxy for the setting of analysis.
 * <p>The methods of this subclass initialize the 
 * instance of analysis setting proxy for
 * validation of the program, that is, country, analysis type, start year, end year
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1
 * @since   1.0(4/1/2020) 
 */
public class AnalysisSettingProxy extends Proxy{
	public static final String NAME = "AnalysisSettingProxy";
	
	public static final String BAR = "bar chart";
	public static final String SCATTER = "scatter chart";
	public static final String LINE = "line chart";
	public static final String PIE = "pie chart";
	public static final String REPORT = "report";
	
	private AnalysisSettingDefine mData;
	

    /**
	 * This override method is used to construct object of the analysis setting of proxy
	 */
	public AnalysisSettingProxy() {
		super(NAME);
	}
	 /**
	 * This method is a named group of Java statements that can be called
	 */
	@Override
	public void init(){
		System.out.println("AnalysisSettingProxy->init()");
		
	    mData = new AnalysisSettingDefine();
	    mData.Countries = new HashMap<String, CountryInfo>();
	    mData.Analysis = new HashMap<String, AnalysisInfo>();
	    mData.currentViewers = new ArrayList<String>();
	    setupData();
	}
	
	
	/**
	 * This method is used to attempt the country with validation.
	 * @param country This is the country to be validated
	 */
	public void tryCountry(String country){
		if(mData.CurrentCountry != null && mData.CurrentCountry.equals(country))
			return;
		
		//set up response
		EventList.ValidationResponse response = new EventList.ValidationResponse();
		response.type = EventList.VALIDATION_RESPONSE_TYPE.COUNTRY;
		
		CountryInfo info = mData.Countries.get(country);
		//if invalid country
		if(!info.Availability){
			response.result = Common.VALIDATION_FAILED;
			response.errorMsg = "The selected country is not available!";
			mData.CurrentCountry = null;
			mData.CurrentAnalysisType = null;
			mData.CurrentStartYear = null;
			mData.CurrentEndYear = null;
			Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			return;
		}
		
		//if valid country
		response.result = Common.VALIDATION_SUCCESS;
		mData.CurrentCountry = country;
		mData.CurrentStartYear = null;
		mData.CurrentEndYear = null;
		Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
	}
	
	/**
	 * This method is used to attempt analysisType with validation
	 * @param  analysisType This is the analysis type selected to be validated
	 */	
	public void tryAnalysisType(String analysisType){
		if(mData.CurrentAnalysisType != null && mData.CurrentAnalysisType.equals(analysisType))
			return;
		
		//set up response
		EventList.ValidationResponse response = new EventList.ValidationResponse();
		response.type = VALIDATION_RESPONSE_TYPE.ANALYSIS_TYPE;
		response.result = Common.VALIDATION_SUCCESS;
		
		//empty parameters
		if(mData.CurrentStartYear != null)
			mData.CurrentStartYear = null;
		
		if(mData.CurrentEndYear != null)
			mData.CurrentEndYear = null;
		
		mData.currentViewers.clear();
		
		mData.CurrentAnalysisType = analysisType;
		Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
	}
	
	
	/**
	 * This method is used to attempt the start year of the type of analysis selected with validation
	 */	
	public void tryStartYear(String startYear){
		if(mData.CurrentStartYear != null && mData.CurrentStartYear.equals(startYear))
			return;
		
		//set up response
		EventList.ValidationResponse response = new EventList.ValidationResponse();
		response.type = EventList.VALIDATION_RESPONSE_TYPE.START_YEAR;
		
		if(startYear == ".")
		{
			mData.CurrentStartYear = null;
			response.result = Common.VALIDATION_SUCCESS;
			Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
		}
		else if(mData.CurrentCountry == null)
		{
			response.result = Common.VALIDATION_FAILED;
			response.errorMsg = "Please select a country before select start year";
			mData.CurrentCountry = null;
			mData.CurrentAnalysisType = null;
			mData.CurrentStartYear = null;
			mData.CurrentEndYear = null;
			Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
		}
		else {
			CountryInfo info = mData.Countries.get(mData.CurrentCountry);
			Integer year = Integer.parseInt(startYear);
			if(mData.Countries.get(mData.CurrentCountry).StartYear > year){
				response.result = Common.VALIDATION_FAILED;
				response.errorMsg = "The data cannot be fetched for this period, \n please select another start year!";
				mData.CurrentStartYear = null;
				mData.CurrentEndYear = null;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
			else if(mData.CurrentEndYear != null && mData.CurrentEndYear < year) {
				response.result = Common.VALIDATION_FAILED;
				response.errorMsg = "Start year must before end year!";
				mData.CurrentStartYear = null;
				mData.CurrentEndYear = null;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
			else {
				mData.CurrentStartYear = year;
				response.result = Common.VALIDATION_SUCCESS;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
		}
	}
	
	
	/**
	 * This method is used to attempt the start year of the type of analysis selected with validation
	 * @param endYear This is the end year selected to be validated
	 */	
	public void tryEndYear(String endYear){
		if(mData.CurrentEndYear != null && mData.CurrentEndYear.equals(endYear))
			return;
		
		//set up response
		EventList.ValidationResponse response = new EventList.ValidationResponse();
		response.type = EventList.VALIDATION_RESPONSE_TYPE.START_YEAR;
		
		if(endYear == ".")
		{
			mData.CurrentStartYear = null;
			response.result = Common.VALIDATION_SUCCESS;
			Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
		}
		else if(mData.CurrentCountry == null)
		{
			response.result = Common.VALIDATION_FAILED;
			response.errorMsg = "Please select a country before select start year";
			mData.CurrentStartYear = null;
			mData.CurrentEndYear = null;
			Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
		}
		else {
			CountryInfo info = mData.Countries.get(mData.CurrentCountry);
			Integer year = Integer.parseInt(endYear);
			if(mData.Countries.get(mData.CurrentCountry).EndYear < year){
				response.result = Common.VALIDATION_FAILED;
				response.errorMsg = "The data cannot be fetched for this period, \n please select another end year!";
				mData.CurrentStartYear = null;
				mData.CurrentEndYear = null;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
			else if(mData.CurrentStartYear != null && mData.CurrentStartYear > year) {
				response.result = Common.VALIDATION_FAILED;
				response.errorMsg = "End year must after start year!";
				mData.CurrentStartYear = null;
				mData.CurrentEndYear = null;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
			else {
				mData.CurrentEndYear = year;
				response.result = Common.VALIDATION_SUCCESS;
				Facade.getInstance().eventTrigger(EventList.VALIDATION_RESPONSE, response);
			}
		}
	}
	
	
	public void tryAddViewer(String viewer) {
		AddViewerResponse response = new AddViewerResponse();
		if(mData.currentViewers.contains(viewer)){
			response.result = false;
			response.errorMsg = "The viewer has already been selected, please reselect!";
		}
		else if(mData.CurrentAnalysisType == null) {
			response.result = false;
			response.errorMsg = "Please select analysis type before adding viewer!";
		}
		else if(viewer.equals(PIE) && mData.Analysis.get(mData.CurrentAnalysisType).PieChart == false) {
			response.result = false;
			response.errorMsg = "Current analysis type does not support this viewer!";
		}
		else if(!viewer.equals(PIE) && mData.Analysis.get(mData.CurrentAnalysisType).PieChart == true) {
			response.result = false;
			response.errorMsg = "Current analysis type does not support this viewer!";
		}
		else {
			response.result = true;
			mData.currentViewers.add(viewer);
		}
		
		Facade.getInstance().eventTrigger(EventList.ADD_VIEWER_RESPONSE, response);
	}

	
	public void tryRemoveViewer(String viewer) {
		RemoveViewerResponse response = new RemoveViewerResponse();
		if(mData.CurrentAnalysisType == null){
			response.result = false;
			response.errorMsg = "Please first select analysis type!";
		}
		else if(!mData.currentViewers.contains(viewer)){
			response.result = false;
			response.errorMsg = "The viewer has not been added!";
		}
		else {
			response.result = true;
			mData.currentViewers.remove(viewer);
		}
		
		Facade.getInstance().eventTrigger(EventList.REMOVE_VIEWER_RESPONSE, response);
	}
	
	
	public Iterator<String> retrieveAllCountries(){
		//sort country names in alphabet order
		ArrayList<String> lst = new ArrayList<String>();
		Iterator<String> it = mData.Countries.keySet().iterator();
		while(it.hasNext())
		{
			lst.add(it.next());
		}
		
		Collections.sort(lst);
		return lst.iterator();
	}
	
	/**
	 * This method is used to retrieve group of analysis types in an iterative method 
	 */	
	public Iterator<String> retrieveAllAnalysisType()
	{
		ArrayList<String> analysis = new ArrayList<String>();
		Iterator<String> iterator = mData.Analysis.keySet().iterator();
		while(iterator.hasNext())
		{
			String analysisType = iterator.next();
			if(mData.Analysis.get(analysisType).PieChart != null)
				analysis.add(analysisType);
		}
		
		return analysis.iterator();
	}
	
	public Integer[] retrievePeriod()
	{
		Integer minStart = null;
		Integer maxEnd = null;
		for(Iterator iterator = mData.Countries.keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			Integer currentStart = mData.Countries.get(key).StartYear;
			Integer currentEnd = mData.Countries.get(key).EndYear;
			System.out.println(mData.Countries.get(key).Name + ": " + currentEnd);
			if(minStart == null || minStart > currentStart)
				minStart = currentStart;
			
			if(maxEnd == null || maxEnd < currentEnd)
				maxEnd = currentEnd;
			

		}
		return new Integer[] {2000, 2020};
	}
	
	/**
	 * This method is used to set up and stores all relevant information required. 
	 * This function produces an object contains start and end date, analysis type
	 */
	
	public String retrieveData(String analysisType){
		String countryName = mData.CurrentCountry;
		Integer startYear = mData.CurrentStartYear;
		Integer endYear = mData.CurrentEndYear;
		
		CountryInfo info = mData.Countries.get(countryName);
		String iso3 = info.ISO3DigitAlpha;
		
		AnalysisInfo aInfo = mData.Analysis.get(analysisType);
		String urlCode = aInfo.Url;
		
		String request = String.format(
				"http://api.worldbank.org/v2/country/%s/indicator/%s?date=%s:%s&format=json", iso3, urlCode, startYear.toString(), endYear.toString());
		
		System.out.println(request);
		
		try {
			URL url = new URL(request);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			int responsecode = conn.getResponseCode();
			if (responsecode == 200) {
				String inline = "";
				Scanner sc = new Scanner(url.openStream());
				while (sc.hasNext()) {
					inline += sc.nextLine();
				}
				sc.close();
				
				return inline;
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block e.printStackTrace();
		}
		
		return null;

	}
	
	public String getCurrentCountry() {
		return mData.CurrentCountry;
	}
	
	public String getCurrentAnalysisType() {
		return mData.CurrentAnalysisType;
	}
	
	public String getCurrentStartYear() {
		if(mData.CurrentStartYear == null)
			return null;
		return mData.CurrentStartYear.toString();
	}
	
	public String getCurrentEndYear() {
		if(mData.CurrentEndYear == null)
			return null;
		return mData.CurrentEndYear.toString();
	}
	
	public ArrayList<String> getCurrentViewers()
	{
		return mData.currentViewers;
	}
	
	
	/**
	 * This method is used to set up and stores all relevant information required. 
	 * This function produces an object contains start and end date, analysis type
     * by catching exceptions from json file
	 */
	private void setupData()
	{
		try 
		{
			FileReader reader = new FileReader(Common.getJsonAddress("CountryDefine.txt"));
		    JSONParser jsonParser = new JSONParser();
		    
		    JSONObject object = (JSONObject)jsonParser.parse(reader);
		    
		    for(Iterator iterator = object.keySet().iterator(); iterator.hasNext();) {
		        String key = (String) iterator.next();
		        
		        JSONObject jsonInfo = (JSONObject)object.get(key);
		        String country = (String)jsonInfo.get("Name");
		        String nameAbbreviation = (String)jsonInfo.get("NameAbbreviation");
		        String ISO2DigitAlpha = (String)jsonInfo.get("ISO2DigitAlpha");
		        String ISO3DigitAlpha = (String)jsonInfo.get("ISO3DigitAlpha");
		        Long code = (Long)jsonInfo.get("Code");
		        Long startYear = (Long)jsonInfo.get("StartYear");
		        Long endYear = (Long)jsonInfo.get("EndYear");
		        boolean availability = (boolean)jsonInfo.get("Availability");
		        
		        CountryInfo info = new CountryInfo();
		        info.Name = country;
		        info.Code = code.intValue();
		        info.StartYear = startYear.intValue();
		        info.EndYear = endYear.intValue();
		        info.ISO2DigitAlpha = ISO2DigitAlpha;
		        info.ISO3DigitAlpha = ISO3DigitAlpha;
		        info.Availability = availability;
		        mData.Countries.put(nameAbbreviation, info);
		    }
		    
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("CountryDefine.txt not found");
		}
		catch (IOException e) 
		{
			System.out.println("Cannot parse CountryDefine.txt");
		} 
	    catch (ParseException e) {
			System.out.println("Cannot parse CountryDefine.txt");
		}
		
		
		try 
		{
			FileReader reader = new FileReader(Common.getJsonAddress("AnalysisTypeDefine.txt"));
		    JSONParser jsonParser = new JSONParser();
		    
		    JSONObject object = (JSONObject)jsonParser.parse(reader);
		    
		    for(Iterator iterator = object.keySet().iterator(); iterator.hasNext();) {
		        String key = (String) iterator.next();
		        
		        JSONObject jsonInfo = (JSONObject)object.get(key);
		        String type = (String)jsonInfo.get("AnalysisType");
		        Boolean pieChart = (jsonInfo.get("PieChart") == null)? null: (Boolean)jsonInfo.get("PieChart");
		        String url = (jsonInfo.get("Url") == null)? "": (String)jsonInfo.get("Url");
		        
		        AnalysisInfo info = new AnalysisInfo();
		        info.PieChart = pieChart;
		        info.Url = url;
		        mData.Analysis.put(type, info);
		    }
		    
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("CountryDefine.txt not found");
		}
		catch (IOException e) 
		{
			System.out.println("Cannot parse CountryDefine.txt");
		} 
	    catch (ParseException e) {
			System.out.println("Cannot parse CountryDefine.txt");
		}
	}
	
}
