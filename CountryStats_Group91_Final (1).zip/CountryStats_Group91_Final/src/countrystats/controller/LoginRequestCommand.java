/**
 * 
 */
package countrystats.controller;


import countrystats.model.UserAccountProxy;
import countrystats.projectbase.interfaces.ICommand;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;

/**
 * This class serves purpose initiate an login 
 * event command to get input of user and try validation
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class LoginRequestCommand extends Command{
	
	/**
	 * This method is used to execute login operation
	 * @param event, the event object to initiate the system
	 */
	@Override
	public void execute(IEvent event)
	{
		System.out.println("LoginRequestCommand->execute()");
		String[] info = (String[])event.getBody();
		
		UserAccountProxy proxy = (UserAccountProxy)Facade.getInstance().getProxy(UserAccountProxy.NAME);
		proxy.tryLogin(info[0], info[1]);
	}
}
