/**
 * 
 */
package countrystats.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.proxy.Proxy;

/**
 * This subclass consists exclusively static methods that
 * set collections of proxy for the analysis.
 * <p>The methods of this subclass initialize the 
 * instance of analysis proxy
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class AnalysisProxy extends Proxy{
	
	/**
	 * The name of the AnalysisProxy
	 */
	public static final String NAME = "AnalysisProxy";

  	/**
	 * This override method is used to construct object of the analysis type of proxy
	 */
	public AnalysisProxy() {
		super(NAME);
		// TODO Auto-generated constructor stub
	}

  	/**
	 * This method is a named group of Java statements that can be called
	 */
	public void init() {
		return;
	}
}
