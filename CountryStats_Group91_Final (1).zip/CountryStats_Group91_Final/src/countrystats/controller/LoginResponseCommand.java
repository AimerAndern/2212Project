/**
 * 
 */
package countrystats.controller;

import countrystats.model.AnalysisSettingDefine;
import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.tool.Common;
import countrystats.view.MainViewMediator;

/**
 * This class consists exclusively of static methods that
 * set collections.
 * <p>The methods of this subclass initialize the 
 * instance to receive login command response 
 * from other subclasses of the program.
 *
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class LoginResponseCommand extends Command{
	@Override
	/**
	 * This override method is used to execute the mediator operation
	 * @param event, the event object to initiate the system
	 */
	public void execute(IEvent event)
	{
		System.out.println("LoginResponseCommand->execute()");
		boolean loginResult = (boolean)event.getBody();
		
		if(loginResult == Common.LOGIN_FAILED)
			return;
		
		Facade.getInstance().addProxy(new AnalysisSettingProxy());
		
		MainViewMediator m = new MainViewMediator();
		Facade.getInstance().addMediator(m);
		
		AnalysisSettingProxy p = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		m.setupCountry(p.retrieveAllCountries());
		m.setupAnalysisType(p.retrieveAllAnalysisType());
		m.setupYear(p.retrievePeriod());
	}
}
