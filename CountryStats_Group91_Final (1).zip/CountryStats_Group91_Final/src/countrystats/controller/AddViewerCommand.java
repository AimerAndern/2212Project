/**
 * 
 */
package countrystats.controller;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;

/**
* A Singleton Command subclass.
* The AddViewerCommand adds new viewers on the screen
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class AddViewerCommand extends Command{
	
	/**
	 * This method triggers the execute of an event to add new viewers
	 */
	public void execute(IEvent event){
		String viewer = (String)event.getBody();
		if(viewer.equals("."))
			return;
		
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		proxy.tryAddViewer(viewer);
	}
}
