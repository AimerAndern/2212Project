/**
 * 
 */
package countrystats.controller;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JTextArea;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.data.json.impl.JSONObject;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.interfaces.IFacade;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.projectbase.patterns.proxy.Proxy;
import countrystats.tool.Analysis;
import countrystats.tool.EventList;
import countrystats.view.MainViewMediator;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

/**
* A Singleton Command subclass.
* The CalculateAnalysisCommand does data analysis based on data input from the WorldBank database
*
* @author  Yiran Shao
* @version 1.0
* @since   2021-04-04
*/
public class CalculateAnalysisCommand extends Command{
	
	/**
	 * The name of the bar chart
	 */
	public static final String BAR = "bar chart";
	
	/**
	 * The name of the scattered plot
	 */
	public static final String SCATTER = "scatter chart";
	
	/**
	 * The name of the line chart
	 */
	public static final String LINE = "line chart";
	
	/**
	 * The name of the pie chart
	 */
	public static final String PIE = "pie chart";
	
	/**
	 * The name of the text report
	 */
	public static final String REPORT = "report";
	
	/**
	 * This method retrieves all data needed according to the specific analysis type request send from the user
	 */
	public void execute(IEvent event) {
		System.out.println("CalcAnalysisCommand->execute()");
		
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		String analysisType = proxy.getCurrentAnalysisType();
		
		
		if (analysisType.equals(Analysis.CO2_VS_ENERGY_VS_PM)) {
			handleCo2VsEnergyVsPM();

			return;
		}
		
		if (analysisType.equals(Analysis.PM_VS_FOREST_AREA)) {
			handlePmVsForest();
			return;
		}
		
		if (analysisType.equals(Analysis.RATIO_CO2_GDP_PER_CAPITA)) {
			handleRatioCo2Gdp();
			
			return;
		}
		
		if (analysisType.equals(Analysis.AVG_FOREST_AREA)) {
			handleAvgForestArea();
			
			return;
		}
		
		if (analysisType.equals(Analysis.AVG_GOV_EXP_ON_EDUCATION)) {
			handleAvgEduExp();
			return;
		}
		
		if (analysisType.equals(Analysis.RATIO_HOSPITALBED_HEALTH_EXP)) {
			handleHospitalBedVsHealthExp();
			return;
		}
		
		if (analysisType.equals(Analysis.HEALTH_EXP_PER_CAPITA_VS_MORTALITY)) {
			handleHealthExpVsMortality();
			
			return;
		}
		
		if (analysisType.equals(Analysis.AVG_GOV_EXP_ON_EDUCATION_VS_HEALTH_EXP)) {
			handleAvgEduExpVsHealthExp();
			
			return;
		}
		
	}


	/**
	 * This method extracts values required to generate viewers from the JSON files retrieved from the WorldBank database
	 * @param analysisType The analysis type specified by the user
	 * @return ArrayList of values required to generate viewer
	 */
	public ArrayList<Double> getValue(String analysisType) 
	{
		try {
			AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
			String inline = proxy.retrieveData(analysisType);
			
			ArrayList<Double> retrievedDataList = new ArrayList<Double>();
			
			JsonArray jsonArray = new JsonParser().parse(inline).getAsJsonArray();
			int size = jsonArray.size();
			int sizeOfResults = jsonArray.get(1).getAsJsonArray().size();
			int year;
			for (int i = 0; i < sizeOfResults; i++) {
				if (jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value").isJsonNull())
					retrievedDataList.add(null);
				else
					retrievedDataList.add(jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value")
							.getAsDouble());
			}
			return retrievedDataList;
			
		} 
		catch (Exception e) {
			System.out.println("error in requesting world bank data");
		}
		
		return null;
		
	}
	
	/**
	 * This method handles the plotting request related with the ratio between CO2 and GDP
	 */
	private void handleRatioCo2Gdp() {
		ArrayList<Double> co2List = getValue(Analysis.CO2_EMISSION);
		ArrayList<Double> gdpList = getValue(Analysis.GDP_PER_CAPITA);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(co2List.get(i) != null && gdpList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset1 = new DefaultCategoryDataset();
			DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(co2List.get(endYear - i) == null || gdpList.get(endYear - i) == null)
					continue;
				dataset1.setValue(co2List.get(endYear - i), Analysis.CO2_EMISSION, i.toString());
				dataset2.setValue(gdpList.get(endYear - i), Analysis.GDP_PER_CAPITA, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer1 = new BarRenderer();
			BarRenderer barrenderer2 = new BarRenderer();

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, barrenderer1);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("metric tons per capita"));

			plot.setDataset(1, dataset2);
			plot.setRenderer(1, barrenderer2);
			plot.setRangeAxis(1, new NumberAxis("US$"));

			
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(co2List.get(endYear - i) == null || gdpList.get(endYear - i) == null)
					continue;
				
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.CO2_EMISSION + " => " + co2List.get(endYear - i).toString() + " metric tons per capita\n"
								         + "\t" + Analysis.GDP_PER_CAPITA + " => " + gdpList.get(endYear - i).toString() + " US$\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.CO2_EMISSION);
			TimeSeries series2 = new TimeSeries(Analysis.GDP_PER_CAPITA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(co2List.get(endYear - i) == null || gdpList.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), co2List.get(endYear - i));
				series2.add(new Year(i), gdpList.get(endYear - i));
			}
			
			TimeSeriesCollection dataset1 = new TimeSeriesCollection();
			dataset1.addSeries(series1);
				
			TimeSeriesCollection dataset2 = new TimeSeriesCollection();
			dataset2.addSeries(series2);
				
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(0, new NumberAxis("metric tons per capita"));
				
			plot.setDataset(1, dataset2);
			plot.setRenderer(1, itemrenderer2);
			plot.setRangeAxis(1, new NumberAxis("US$"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.PM_2_5);
			XYSeries series2 = new XYSeries(Analysis.FOREST_AREA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(co2List.get(endYear - i) == null || gdpList.get(endYear - i) == null)
					continue;
				
				series1.add(i, co2List.get(endYear - i));
				series2.add(i, gdpList.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
		
	}
	
	/**
	 * This method handles the This method handles the plotting request related with CO2, Energy and PM
	 */
	private void handleCo2VsEnergyVsPM() {
		ArrayList<Double> CO2List = getValue(Analysis.CO2_EMISSION);
		ArrayList<Double> EnergyList = getValue(Analysis.ENERGY_USE);
		ArrayList<Double> PM25List = getValue(Analysis.PM_2_5);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(CO2List.get(i) != null && EnergyList.get(i) != null && PM25List.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset1 = new DefaultCategoryDataset();
			DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
			DefaultCategoryDataset dataset3 = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(CO2List.get(endYear - i) == null || EnergyList.get(endYear - i) == null || PM25List.get(endYear - i) == null)
					continue;
				dataset1.setValue(CO2List.get(endYear - i), Analysis.ENERGY_USE, i.toString());
				dataset2.setValue(EnergyList.get(endYear - i), Analysis.CO2_EMISSION, i.toString());
				dataset1.setValue(PM25List.get(endYear - i), Analysis.PM_2_5, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer1 = new BarRenderer();
			BarRenderer barrenderer2 = new BarRenderer();
			BarRenderer barrenderer3 = new BarRenderer();

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, barrenderer1);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis(""));

			plot.setDataset(1, dataset2);
			plot.setRenderer(1, barrenderer2);
			plot.setRangeAxis(1, new NumberAxis("US$"));

			
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(CO2List.get(endYear - i) == null || EnergyList.get(endYear - i) == null || PM25List.get(endYear - i) == null)
					continue;
				
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.CO2_EMISSION + " => " + CO2List.get(endYear - i).toString() + " metric tons per capita\n"
								         + "\t" + Analysis.ENERGY_USE + " => " + EnergyList.get(endYear - i).toString() + " kg of oil equivalent per capita\n"
								         + "\t" + Analysis.PM_2_5 + "=>" + PM25List.get(endYear - i).toString() + " micrograms per cubic meter\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.CO2_EMISSION);
			TimeSeries series2 = new TimeSeries(Analysis.ENERGY_USE);
			TimeSeries series3 = new TimeSeries(Analysis.PM_2_5);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(CO2List.get(endYear - i) == null || EnergyList.get(endYear - i) == null || PM25List.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), CO2List.get(endYear - i));
				series2.add(new Year(i), EnergyList.get(endYear - i));
				series3.add(new Year(i), PM25List.get(endYear - i));
			}
			
			TimeSeriesCollection dataset1 = new TimeSeriesCollection();
			dataset1.addSeries(series1);
				
			TimeSeriesCollection dataset2 = new TimeSeriesCollection();
			dataset2.addSeries(series2);
				
			TimeSeriesCollection dataset3 = new TimeSeriesCollection();
			dataset3.addSeries(series3);
			
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer3 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("metric tons per capita"));
				
			plot.setDataset(1, dataset2);
			plot.setRenderer(1, itemrenderer2);
			plot.setRangeAxis(new NumberAxis("kg of oil equivalent per capita"));
				
			plot.setDataset(2, dataset3);
			plot.setRenderer(2, itemrenderer3);
			plot.setRangeAxis(new NumberAxis("micrograms per cubic meter"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis
			plot.mapDatasetToRangeAxis(2, 2); // 2nd dataset to 2nd y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.CO2_EMISSION);
			XYSeries series2 = new XYSeries(Analysis.ENERGY_USE);
			XYSeries series3 = new XYSeries(Analysis.PM_2_5);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(CO2List.get(endYear - i) == null || EnergyList.get(endYear - i) == null || PM25List.get(endYear - i) == null)
					continue;
				
				series1.add(i, CO2List.get(endYear - i));
				series2.add(i, EnergyList.get(endYear - i));
				series3.add(i, PM25List.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
			dataset.addSeries(series3);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
		
	}

	/**
	 * This method handles the plotting request related with PM2.5 and Forest area
	 */
	private void handlePmVsForest() {
		ArrayList<Double> pm25List = getValue(Analysis.PM_2_5);
		ArrayList<Double> forestList = getValue(Analysis.FOREST_AREA);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(pm25List.get(i) != null && forestList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset1 = new DefaultCategoryDataset();
			DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(pm25List.get(endYear - i) == null || forestList.get(endYear - i) == null)
					continue;
				dataset1.setValue(pm25List.get(endYear - i), Analysis.PM_2_5, i.toString());
				dataset2.setValue(forestList.get(endYear - i), Analysis.FOREST_AREA, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer1 = new BarRenderer();
			BarRenderer barrenderer2 = new BarRenderer();

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, barrenderer1);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis(""));

			plot.setDataset(1, dataset2);
			plot.setRenderer(1, barrenderer2);
			plot.setRangeAxis(1, new NumberAxis(""));

			
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(pm25List.get(endYear - i) == null || forestList.get(endYear - i) == null)
					continue;
				
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.CO2_EMISSION + " => " + pm25List.get(endYear - i).toString() + " micrograms per cubic meter\n"
								         + "\t" + Analysis.ENERGY_USE + " => " + forestList.get(endYear - i).toString() + " % of land area\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.PM_2_5);
			TimeSeries series2 = new TimeSeries(Analysis.FOREST_AREA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(pm25List.get(endYear - i) == null || forestList.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), pm25List.get(endYear - i));
				series2.add(new Year(i), forestList.get(endYear - i));
			}
			
			TimeSeriesCollection dataset1 = new TimeSeriesCollection();
			dataset1.addSeries(series1);
				
			TimeSeriesCollection dataset2 = new TimeSeriesCollection();
			dataset2.addSeries(series2);
				
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("micrograms per cubic meter"));
				
			plot.setDataset(1, dataset2);
			plot.setRenderer(1, itemrenderer2);
			plot.setRangeAxis(new NumberAxis("% of land area"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.PM_2_5);
			XYSeries series2 = new XYSeries(Analysis.FOREST_AREA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(pm25List.get(endYear - i) == null || forestList.get(endYear - i) == null)
					continue;
				
				series1.add(i, pm25List.get(endYear - i));
				series2.add(i, forestList.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
		
	}

	/**
	 * This method handles the plotting request related with average Forest area
	 */
	private void handleAvgForestArea() {
		ArrayList<Double> forestList = getValue(Analysis.FOREST_AREA);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(forestList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		if(viewer.contains(PIE)) {
			Double avg = 0.0;
			int years = 0;
			for(int i = 0; i <= endYear - startYear; i++) {
				if(forestList.get(i) != null) {
					years++;
					avg += forestList.get(i);
				}
			}
			
			avg = avg / years;
			
			DefaultPieDataset dataset = new DefaultPieDataset();
			dataset.setValue("average forest area", avg);
			dataset.setValue("average non-forest area", 100 - avg);

			JFreeChart pieChart = ChartFactory.createPieChart(Analysis.AVG_FOREST_AREA, dataset, true, true, false);
		
			Facade.getInstance().eventTrigger(EventList.ADD_PIE, pieChart);
		}
	}
	
	/**
	 * This method handles the plotting request related with Government expension on education and GDP per capita
	 */
	private void handleAvgEduExp() {
		ArrayList<Double> educationList = getValue(Analysis.GOV_EXP_ON_EDUCATION);
		ArrayList<Double> gdpList = getValue(Analysis.GDP_PER_CAPITA);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(educationList.get(i) != null && gdpList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		if(viewer.contains(PIE)) {
			Double avgExp = 0.0;
			Double avgGdp = 0.0;
			int years = 0;
			for(int i = 0; i <= endYear - startYear; i++) {
				if(educationList.get(i) != null && gdpList.get(i) != null) {
					years++;
					avgExp += educationList.get(i);
					avgGdp += gdpList.get(i);
				}
			}
			
			avgExp = avgExp / years;
			avgGdp = avgGdp / years;
			
			DefaultPieDataset dataset = new DefaultPieDataset();
			dataset.setValue("Average of Government expenditure on education", avgExp);
			dataset.setValue("Average of Government expenditure on other area", avgGdp - avgExp);

			JFreeChart pieChart = ChartFactory.createPieChart(Analysis.AVG_GOV_EXP_ON_EDUCATION, dataset, true, true, false);
		
			Facade.getInstance().eventTrigger(EventList.ADD_PIE, pieChart);
		}
	}
	
	/**
	 * This method handles the plotting request related with Number of hospital beds and Current health expenditure
	 */
	private void handleHospitalBedVsHealthExp() {
		ArrayList<Double> hospitalList = getValue(Analysis.HOSPITAL_BEDS);
		ArrayList<Double> healthList = getValue(Analysis.CURRENT_HEALTH_EXP);
		// Convert Current health expenditure per capita to Current health expenditure (per 1,000 people)
		for (int i = 0; i < healthList.size(); i++) {
			if(healthList.get(i) != null)
				healthList.set(i,(healthList.get(i) * 1000.0));
		}
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(hospitalList.get(i) != null && healthList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(hospitalList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				dataset.setValue(hospitalList.get(endYear - i), Analysis.HOSPITAL_BEDS, i.toString());
				dataset.setValue(healthList.get(endYear - i), Analysis.CURRENT_HEALTH_EXP_PER_CAPITA, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer = new BarRenderer();

			plot.setDataset(0, dataset);
			plot.setRenderer(0, barrenderer);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("per 1000 people"));
			
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(hospitalList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
			
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.HOSPITAL_BEDS + " => " + hospitalList.get(endYear - i).toString() + " per 1000 people\n"
								         + "\t" + Analysis.CURRENT_HEALTH_EXP_PER_CAPITA + " => " + healthList.get(endYear - i).toString() + " per 1000 people\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.HOSPITAL_BEDS);
			TimeSeries series2 = new TimeSeries(Analysis.CURRENT_HEALTH_EXP_PER_CAPITA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(hospitalList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), hospitalList.get(endYear - i));
				series2.add(new Year(i), healthList.get(endYear - i));
			}
			
			TimeSeriesCollection dataset = new TimeSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("per 1000 people"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.PM_2_5);
			XYSeries series2 = new XYSeries(Analysis.FOREST_AREA);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(hospitalList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				
				series1.add(i, hospitalList.get(endYear - i));
				series2.add(i, healthList.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
	}
	
	/**
	 * This method handles the plotting request related with Current health expenditure per capita and motality rate of infants
	 */
	private void handleHealthExpVsMortality() {
		ArrayList<Double> healthPerCapitaList = getValue(Analysis.CURRENT_HEALTH_EXP_PER_CAPITA);
		ArrayList<Double> mortalityList = getValue(Analysis.MORTALITY_RATE_INFANT);
		
		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(healthPerCapitaList.get(i) != null && mortalityList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset1 = new DefaultCategoryDataset();
			DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(healthPerCapitaList.get(endYear - i) == null || mortalityList.get(endYear - i) == null)
					continue;
				dataset1.setValue(healthPerCapitaList.get(endYear - i), Analysis.CURRENT_HEALTH_EXP_PER_CAPITA, i.toString());
				dataset2.setValue(mortalityList.get(endYear - i), Analysis.MORTALITY_RATE_INFANT, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer1 = new BarRenderer();
			BarRenderer barrenderer2 = new BarRenderer();

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, barrenderer1);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("US$"));

			plot.setDataset(1, dataset2);
			plot.setRenderer(1, barrenderer2);
			plot.setRangeAxis(1, new NumberAxis("per 1,000 live births"));

			
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(healthPerCapitaList.get(endYear - i) == null || mortalityList.get(endYear - i) == null)
					continue;
				
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.CURRENT_HEALTH_EXP_PER_CAPITA + " => " + healthPerCapitaList.get(endYear - i).toString() + " US$\n"
								         + "\t" + Analysis.MORTALITY_RATE_INFANT + " => " + mortalityList.get(endYear - i).toString() + " per 1,000 live births\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.CURRENT_HEALTH_EXP);
			TimeSeries series2 = new TimeSeries(Analysis.MORTALITY_RATE_INFANT);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(healthPerCapitaList.get(endYear - i) == null || mortalityList.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), healthPerCapitaList.get(endYear - i));
				series2.add(new Year(i), mortalityList.get(endYear - i));
			}
			
			TimeSeriesCollection dataset1 = new TimeSeriesCollection();
			dataset1.addSeries(series1);
				
			TimeSeriesCollection dataset2 = new TimeSeriesCollection();
			dataset2.addSeries(series2);
				
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset1);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("US$"));
				
			plot.setDataset(1, dataset2);
			plot.setRenderer(1, itemrenderer2);
			plot.setRangeAxis(new NumberAxis("per 1,000 live births"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
			plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.CURRENT_HEALTH_EXP_PER_CAPITA);
			XYSeries series2 = new XYSeries(Analysis.MORTALITY_RATE_INFANT);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(healthPerCapitaList.get(endYear - i) == null || mortalityList.get(endYear - i) == null)
					continue;
				
				series1.add(i, healthPerCapitaList.get(endYear - i));
				series2.add(i, mortalityList.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
		
	}
	
	/**
	 * This method handles the plotting request related with Government expenditure on education and Current health expenditure
	 */
	private void handleAvgEduExpVsHealthExp() {
		ArrayList<Double> educationList = getValue(Analysis.GOV_EXP_ON_EDUCATION);
		ArrayList<Double> healthList = getValue(Analysis.CURRENT_HEALTH_EXP);

		MainViewMediator mediator = (MainViewMediator)Facade.getInstance().getMediator(MainViewMediator.NAME);
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
	
		ArrayList<String> viewer = proxy.getCurrentViewers();
		Integer startYear = Integer.parseInt(proxy.getCurrentStartYear());
		Integer endYear = Integer.parseInt(proxy.getCurrentEndYear());
		
		boolean result = false;
		for(int i = 0; i <= endYear - startYear; i++) {
			if(educationList.get(i) != null && healthList.get(i) != null)
				result = true;
		}
		
		//if all data not available
		if(!result) {
			Facade.getInstance().eventTrigger(EventList.CALCULATE_ANALYSIS_RESPONSE, false);
			return;
		}
		
		//bar chart
		if(viewer.contains(BAR)) {
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			for(Integer i = endYear; i >=startYear; i--) {
				if(educationList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				dataset.setValue(educationList.get(endYear - i), Analysis.GOV_EXP_ON_EDUCATION, i.toString());
				dataset.setValue(healthList.get(endYear - i), Analysis.CURRENT_HEALTH_EXP, i.toString());
			}
			
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer = new BarRenderer();

			plot.setDataset(0, dataset);
			plot.setRenderer(0, barrenderer);
			CategoryAxis domainAxis = new CategoryAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("% of GDP"));
			
			plot.mapDatasetToRangeAxis(0, 0);

			JFreeChart barChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
			
			
			Facade.getInstance().eventTrigger(EventList.ADD_BAR, barChart);
		}
		
		
		
		if(viewer.contains(REPORT)) {
			JTextArea report = new JTextArea();
			report.setEditable(false);
			report.setPreferredSize(new Dimension(400, 300));
			report.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
			report.setBackground(Color.white);
			String reportMessage, reportMessage2;

			reportMessage = proxy.getCurrentAnalysisType() +  "\n" + "==============================\n";
			for(Integer i = endYear; i >=startYear; i--){
				if(educationList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
			
				reportMessage += "Year " + i.toString() + "\n"
								         + "\t" + Analysis.GOV_EXP_ON_EDUCATION + " => " + educationList.get(endYear - i).toString() + " % of GDP\n"
								         + "\t" + Analysis.CURRENT_HEALTH_EXP + " => " + healthList.get(endYear - i).toString() + " % of GDP\n";
			}

			report.setText(reportMessage);
			Facade.getInstance().eventTrigger(EventList.ADD_REPORT, report);
			
		}
		
		
		if(viewer.contains(SCATTER)) {
			TimeSeries series1 = new TimeSeries(Analysis.GOV_EXP_ON_EDUCATION);
			TimeSeries series2 = new TimeSeries(Analysis.CURRENT_HEALTH_EXP);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(educationList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				
				series1.add(new Year(i), educationList.get(endYear - i));
				series2.add(new Year(i), healthList.get(endYear - i));
			}
			
			TimeSeriesCollection dataset = new TimeSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
			XYItemRenderer itemrenderer2 = new XYLineAndShapeRenderer(false, true);

			plot.setDataset(0, dataset);
			plot.setRenderer(0, itemrenderer1);
			DateAxis domainAxis = new DateAxis("Year");
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis(" % of GDP"));
				
			plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
				
			JFreeChart scatterChart = new JFreeChart(proxy.getCurrentAnalysisType(),
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
				
			Facade.getInstance().eventTrigger(EventList.ADD_SCATTER, scatterChart);
		}
		
		if(viewer.contains(LINE)){
			XYSeries series1 = new XYSeries(Analysis.GOV_EXP_ON_EDUCATION);
			XYSeries series2 = new XYSeries(Analysis.CURRENT_HEALTH_EXP);
			
			for(Integer i = endYear; i >=startYear; i--){
				if(educationList.get(endYear - i) == null || healthList.get(endYear - i) == null)
					continue;
				
				series1.add(i, educationList.get(endYear - i));
				series2.add(i, healthList.get(endYear - i));
			}
			
			XYSeriesCollection dataset = new XYSeriesCollection();
			dataset.addSeries(series1);
			dataset.addSeries(series2);
				
			JFreeChart chart = ChartFactory.createXYLineChart(proxy.getCurrentAnalysisType(), "Year", "", dataset,
					PlotOrientation.VERTICAL, true, true, false);

			XYPlot plot = chart.getXYPlot();

			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.RED);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));

			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);

			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);

			chart.getLegend().setFrame(BlockBorder.NONE);

			chart.setTitle(
					new TextTitle(proxy.getCurrentAnalysisType(), new Font("Serif", java.awt.Font.BOLD, 18)));
				
			Facade.getInstance().eventTrigger(EventList.ADD_LINE, chart);
		}
	}
}
