/**
 * 
 */
package countrystats.controller;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.tool.EventList;

/**
 * This subclass consists exclusively of static methods that
 * operate on proxy after starting the system.
 * <p>The methods of this subclass initialize the 
 * instance of user account proxy and pull a request of  
 * validation for its arguments
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class ValidationRequestCommand extends Command{
	@Override
  	/**
	 * This method is used to execute validation request operation
	 * @param event, the event object contains instances to validated with
	 */
	public void execute(IEvent event) {
		System.out.println("ValidationRequestCommand->execute()");
		
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		
		EventList.ValidationRequest request = (EventList.ValidationRequest)event.getBody();
		if(request.info.equals("."))
			return;
		switch(request.type)
		{
			case COUNTRY:
				proxy.tryCountry(request.info);
				break;
			
			case ANALYSIS_TYPE:
				proxy.tryAnalysisType(request.info);
				break;
			
			case START_YEAR:
				proxy.tryStartYear(request.info);
				break;
				
			case END_YEAR:
				proxy.tryEndYear(request.info);
				break;
				
		}
	}
}
