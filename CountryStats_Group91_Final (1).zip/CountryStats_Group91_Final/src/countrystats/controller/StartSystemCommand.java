package countrystats.controller;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import countrystats.model.AnalysisSettingProxy;
import countrystats.model.UserAccountProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;
import countrystats.view.LoginViewMediator;
import countrystats.view.MainView;
/**
 * This subclass consists exclusively of static methods that
 * set collections of proxy after login success.
 * <p>The methods of this subclass initialize the 
 * instance of user account proxy and login view 
 * event listener for start system response from other 
 * subclasses of the program.
 * @author  Zheng Yang, Rui Zhu
 * @version 1.1(4/5/2021)
 * @since   1.0(4/1/2021) 
 */
public class StartSystemCommand extends Command{
	
	
	/**
	 * This override method is used to execute the start system
     * by getting the instance from facade
	 * @param event, the event object to initiate the system
	 */
	@Override
	public void execute(IEvent event)
	{
		System.out.println("StartSystemCommand->execute()");
	
		
		//register user account proxy
		Facade.getInstance().addProxy(new UserAccountProxy());
		
		//register user account proxy
		Facade.getInstance().addProxy(new AnalysisProxy());
		
		//register login view mediator
		Facade.getInstance().addMediator(new LoginViewMediator());
		
	}
}
