/**
 * 
 */
package countrystats.controller;

import countrystats.model.AnalysisSettingProxy;
import countrystats.projectbase.interfaces.IEvent;
import countrystats.projectbase.patterns.command.Command;
import countrystats.projectbase.patterns.facade.Facade;

/**
* A Singleton Facade subclass.
* The SystemFacade class initialize the system.
*
* @author  Zheng Yang
* @version 1.0
* @since   2021-04-01 
*/
public class RemoveViewerCommand extends Command{
	public void execute(IEvent event){
		String viewer = (String)event.getBody();
		if(viewer.equals("."))
			return;
		
		AnalysisSettingProxy proxy = (AnalysisSettingProxy)Facade.getInstance().getProxy(AnalysisSettingProxy.NAME);
		proxy.tryRemoveViewer(viewer);
	}
}
