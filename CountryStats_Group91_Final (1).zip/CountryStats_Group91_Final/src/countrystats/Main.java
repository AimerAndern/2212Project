package countrystats;

public class Main {

	public static void main(String[] args) {
		SystemFacade.getInstance().startUp();

	}

}
