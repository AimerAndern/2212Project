# CountryStats

CountryStats is a system that a) retrieving demographic and other data for one selected country from the World Bank’s data repository; b) processing, if required, the data using different types of analyses, and c) rendering the retrieved data or the processed data using appropriately selected visualization means such as bar charts, line graphs, scattered plots, and pie charts.

## Getting Started

Download the Maven file from OWL. Open the file using Eclipse with Java JDK 16 and run the  Main.java file.

### Prerequisites

1. Install Eclipse IDE: 
[Eclipse Download Instructions](https://www.oracle.com/java/technologies/javase-downloads.html)

2. Install JDK 16: 
[JDK 16 Download Instructions](https://www.oracle.com/java/technologies/javase-jdk16-downloads.html)

3. Install Maven in Eclipse using m2eclipse: 
[Maven Installation Instructions](https://github.com/eclipse-m2e/m2e-core/blob/master/README.md#-installation)


### Installing

1. Import the CountryStats Maven file into Eclipse

    1. Open Eclipse.

    2. Select File > Import > option.

    3. Select Maven Projects Option. Click on Next Button.

    4. Select Project location of CountryStats

    5. Click Finish Button.

2. Import required jar files

    1. Right click on the CountryStats Project
    2. Select Build Path
    3. Click on Configure Build Path
    4. Click on Libraries and select Add External JARs
    5. Select all jar files from `CountryStats/bin/lib`
    6. Click and Apply and Ok

3. Run CountryStats

    1. Click 'Run Main' to run the program


## Built With

* [World Bank’s API](https://datahelpdesk.worldbank.org/knowledgebase/articles/898581) - Input Data Repository
* [JFreeChart](https://www.jfree.org/jfreechart/) - Chart GUI
* [Google Gson](https://github.com/google/gson) - JSON File Conversion
* [Maven](https://maven.apache.org/) - Dependency Management
* [BitBucket](https://bitbucket.org/) - Git Code Management

## Documentation

Please check `CountryStats/doc` folder to find JavaDocs for all of the classes in this project.

## Contributing

When contributing to this repository, please first discuss the change you wish to make via issue, email, or any other method with the owners of this repository before making a change. 


## Authors

The CS 2212 group 91 team:

* **Zack Yang** - *Architecture and Viewers*
* **Rui Zhu** - *Java Doc Development and Maintenance*
* **Yang Junyi** - *GUI Design and Implementation*
* **Yiran Shao** - *Data Retrieval and Computation*


## License

This project is licensed under the MIT License

## Acknowledgments

We acknowledge the extensive help we received from our professor **Kostas Kontogiannis** and all the TAs. 